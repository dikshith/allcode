package com.spring.training.json;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;


@Path("/emp")
@Singleton
public class EmployeeResource {
	private TreeMap<Integer, Employee> empList=new TreeMap<>();
	
	public EmployeeResource()
	{
		empList.put(101, new Employee(101, "Arvind", "Developer"));
		empList.put(102, new Employee(102, "Rakesh", "Accountant"));
		empList.put(103, new Employee(103, "Arjun", "Architect"));
	}
	
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public List<Employee> getAllEmployees()
	{
		List<Employee> list=new ArrayList<>(empList.values());
		return list;
	}
	
	@GET
	@Path("/{id}")
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML,MediaType.TEXT_HTML})
	public Response findEmployee(@PathParam("id")int empId)
	{
		return Response.ok().entity(empList.get(empId)).build();
	}

	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML,MediaType.APPLICATION_FORM_URLENCODED})
	public Response addEmployee(Employee e)
	{
		int nextId=empList.lastKey()+1;
		e.setId(nextId);
		empList.put(nextId, e);
		URI uri=UriBuilder.fromPath("./emp/"+nextId).build();
		return Response.created(uri).entity("Employee with id "+nextId+" added successfully").build();
		
	}
	
	@PUT
	@Path("/{id}")
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	public String updateEmployee(@PathParam("id") int id,Employee e)
	{
		Employee emp=empList.get(id);
		if(emp==null){
				Response response=Response.status(Status.BAD_REQUEST).entity("No such employee").build();
				throw new WebApplicationException(response);
				
		}
		emp.setName(e.getName());
		emp.setDesignation(e.getDesignation());
		return "Employee with id "+id+" updated successfully";
		
	}
	
	@DELETE
	@Path("/{id}")
	@Produces(MediaType.TEXT_PLAIN)
	public String removeEmployee(@PathParam("id")int id)
	{
		empList.remove(id);
		return "Employee with "+id+" successfully removed";
	}
	
	@GET
	@Path("/throughQuery")
	@Produces(MediaType.TEXT_HTML)
	public String findEmployeeThroughQuery(@QueryParam("emp_id")int id)
	{
		Employee e=empList.get(id);
		String resp="<html><body>";
		resp+="<h3>Name: "+e.getName();
		resp+="<br>Designation:"+e.getDesignation();
		resp+="</h3></body></html>";
		return resp;
	}
	
	@POST
	@Path("/throughForm")
	@Produces(MediaType.TEXT_PLAIN)
	public Response addEmployeeThroughForm(@FormParam("emp_name")String name,@FormParam("designation")String designation)
	{
		Employee emp=new Employee();
		emp.setName(name);
		emp.setDesignation(designation);
		return addEmployee(emp);
	}
	
	
}
