package com.spring.training.json;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

@Path("/context")
public class ContextResource {
	
	@Context
	private HttpHeaders headers;
	
	@Context
	private UriInfo info;
	
	@Path("/headers")
	@Produces(MediaType.TEXT_HTML)
	@GET
	public String getHeaders()
	{
		String resp="<html><body>";
		MultivaluedMap<String, String> map=headers.getRequestHeaders();
		resp+="<table border=1><tr><th>Header Name</th><th>Value</th></tr>";
		
		for(String key:map.keySet()){
			resp+="<tr><td>"+key+"</td>";
			
			List<String> values=map.get(key);
			resp+="<td>";
			for(String value:values){
				resp+=value+" ";
			}
			resp+="</td></tr>";
		}
		resp+="</table></body></html>";
		return resp;
	}
	
	@Path("/info")
	@Produces(MediaType.TEXT_HTML)
	@GET
	public String getUriInfo()
	{
		String resp="<html><body>";
		resp+="<br>Uri Path:"+info.getPath();
		resp+="<br>Absolute Path: "+info.getAbsolutePath();
		resp+="</body></html>";
		return resp;
	}

}
