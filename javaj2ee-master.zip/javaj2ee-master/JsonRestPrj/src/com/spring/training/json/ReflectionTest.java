package com.spring.training.json;

import java.lang.reflect.Method;

public class ReflectionTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class<?> clz=Class.forName("com.spring.training.json.Employee");
			Method[] methods=clz.getDeclaredMethods();
			for(Method method:methods){
				System.out.println(method.getName());
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
