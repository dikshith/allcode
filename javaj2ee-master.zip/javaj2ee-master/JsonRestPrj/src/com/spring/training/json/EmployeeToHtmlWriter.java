package com.spring.training.json;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.Provider;

@Produces(MediaType.TEXT_HTML)
@Provider
public class EmployeeToHtmlWriter implements MessageBodyWriter<Employee>{

	@Override
	public long getSize(Employee e, Class<?> clz, Type type,
			Annotation[] annotations, MediaType mediaType) {
		// TODO Auto-generated method stub
		return -1;
	}

	@Override
	public boolean isWriteable(Class<?> arg0, Type arg1, Annotation[] arg2,
			MediaType arg3) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public void writeTo(Employee employee, Class<?> clz, Type type,
			Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, Object> headers, OutputStream out)
			throws IOException, WebApplicationException {
		// TODO Auto-generated method stub
		
		writeContent(out,"<html><body>");
		writeContent(out, "<h2>Employee Id: "+employee.getId());
		writeContent(out, "<br>Name: "+employee.getName());
		writeContent(out, "<br>Designation:"+employee.getDesignation());
		writeContent(out, "</h2></body></html>");
		
	}

	private void writeContent(OutputStream out, String content) throws IOException {
		// TODO Auto-generated method stub
		out.write(content.getBytes());
	}

}
