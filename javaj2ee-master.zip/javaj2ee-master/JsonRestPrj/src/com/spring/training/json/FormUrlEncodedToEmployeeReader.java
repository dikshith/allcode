package com.spring.training.json;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.ws.rs.ext.Provider;

@Provider
@Consumes(MediaType.APPLICATION_FORM_URLENCODED)

public class FormUrlEncodedToEmployeeReader implements MessageBodyReader<Employee>{

	@Override
	public boolean isReadable(Class<?> arg0, Type arg1, Annotation[] arg2,
			MediaType arg3) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Employee readFrom(Class<Employee> clz, Type type,
			Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, String> headers, InputStream in)
			throws IOException, WebApplicationException {
		// TODO Auto-generated method stub
		System.out.println("invoking readFrom");
		Employee e=new Employee();
		BufferedReader br=new BufferedReader(new InputStreamReader(in));
		String line=br.readLine();
		Map<String, String> map=getRequestMap(line);
		e.setName(map.get("emp_name"));
		e.setDesignation(map.get("designation"));
		return e;
	}

	private Map<String, String> getRequestMap(String line) {
		// TODO Auto-generated method stub
		
		Map<String, String> parameterMap=new HashMap<>();
		String[] parameters=line.split("&");
		for(String parameter:parameters){
			String[] keyValuePair=parameter.split("=");
			parameterMap.put(keyValuePair[0], keyValuePair[1]);
		}
		return parameterMap;
	}

}
