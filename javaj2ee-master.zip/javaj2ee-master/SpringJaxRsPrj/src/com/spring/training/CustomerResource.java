package com.spring.training;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Path("/cust")
public class CustomerResource {
	
	@Autowired
	private Address address;
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String getDetail()
	{
		return "<html><body><h2>"+address.getLocation()+" "+address.getCity()+
				"</h2></body></html>";
	}

}
