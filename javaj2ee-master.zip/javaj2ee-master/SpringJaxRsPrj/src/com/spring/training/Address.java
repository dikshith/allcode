package com.spring.training;

import org.springframework.stereotype.Component;


@Component
public class Address {
	
	public String getLocation()
	{
		return "Hebbal ddddddddddddd";
	}
	
	public String getCity()
	{
		return "Bangalore";
	}

}
