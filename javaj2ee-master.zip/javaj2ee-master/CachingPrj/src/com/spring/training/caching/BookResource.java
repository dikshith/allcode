package com.spring.training.caching;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.inject.Singleton;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.EntityTag;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;


@Path("/book")
@Singleton
public class BookResource {
	private Map<Integer, Book> map=new HashMap<Integer, Book>();
	public BookResource()
	{
		map.put(101, new Book(101, "Head First Java", "Kathy Sierra", 400, new Date()));
		map.put(102, new Book(102, "Python Basics", "Sierra", 500, new Date()));
	}
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("/{id}")
	public Response getBook(@PathParam("id")int id,@Context Request request)
	{
		Book book=map.get(id);
		CacheControl control=new CacheControl();
		control.setMaxAge(120);
		EntityTag eTag=new EntityTag(book.getLastModified().toString());
		ResponseBuilder builder=request.evaluatePreconditions(eTag);
		if(builder!=null){//both are matching
			System.out.println("response is not modified");
			return builder.cacheControl(control).build();
		}
		else{
			System.out.println("response is modified");
			return Response.ok().cacheControl(control).entity(book).tag(eTag).build();
		}
		
	}
	
	@PUT
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/{id}/price/{price}")
	public Response updatePrice(@PathParam("id")int id,@PathParam("price")int price)
	{
		Book book=map.get(id);
		book.setPrice(price);
		book.setLastModified(new Date());
		return Response.ok().entity("price updated").build();
	}

	
}
