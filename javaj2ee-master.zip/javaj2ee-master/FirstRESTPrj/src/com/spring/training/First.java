package com.spring.training;

import javax.ws.rs.CookieParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/first")
public class First {

	@Produces(MediaType.TEXT_HTML)
	@GET
	@Path("/{fname}/{lname}")
	public String getMessage(@PathParam("fname")String firstName,@PathParam("lname")String lastName)
	{
		return "<html><body><h2>Welcome TO REST "+firstName+","+lastName+"</h2></body></html>";
	}
	
	@Produces(MediaType.TEXT_PLAIN)
	@GET
	@Path("/msg")
	public String getNextMessage(@HeaderParam("user-agent")String userAgent,@CookieParam("company")String comp,@CookieParam("language")String lang)
	{
		return "this is a plain message "+userAgent+" Language is "+lang+" Company is "+comp;
	}
	
	@Produces(MediaType.APPLICATION_XML)
	@GET
	@Path("/emp")
	public Employee getEmployee()
	{
		return new Employee(1, "Arvind", "Accountant");
	}
	
	@Produces(MediaType.TEXT_HTML)
	@GET
	@Path("/data")
	public String getData(@MatrixParam("data1")String data1,@MatrixParam("data2")String data2)
	{
		return "<html><body>Data1: "+data1+"<br>Data2: "+data2+"</body></html>"; 
	}
}
