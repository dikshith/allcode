package com.spring.training;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import javax.inject.Singleton;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;


@Path("/emp")
@Singleton
public class EmployeeResource {
	private TreeMap<Integer, Employee> empList=new TreeMap<>();
	
	public EmployeeResource()
	{
		empList.put(101, new Employee(101, "Arvind", "Developer"));
		empList.put(102, new Employee(102, "Rakesh", "Accountant"));
		empList.put(103, new Employee(103, "Arjun", "Architect"));
	}
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Employee> getAllEmployees()
	{
		List<Employee> list=new ArrayList<>(empList.values());
		return list;
	}
	
	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_XML)
	public Employee findEmployee(@PathParam("id")int empId)
	{
		return empList.get(empId);
	}

	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_XML)
	public String addEmployee(Employee e)
	{
		int nextId=empList.lastKey()+1;
		e.setId(nextId);
		empList.put(nextId, e);
		return "Employee with id "+nextId+" added successfully";
		
	}
	
	@PUT
	@Path("/{id}")
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_XML)
	public String updateEmployee(@PathParam("id") int id,Employee e)
	{
		Employee emp=empList.get(id);
		if(emp==null){
				Response response=Response.status(Status.BAD_REQUEST).entity("No such employee").build();
				throw new WebApplicationException(response);
				
		}
		emp.setName(e.getName());
		emp.setDesignation(e.getDesignation());
		return "Employee with id "+id+" updated successfully";
		
	}
	
	@DELETE
	@Path("/{id}")
	@Produces(MediaType.TEXT_PLAIN)
	public String removeEmployee(@PathParam("id")int id)
	{
		empList.remove(id);
		return "Employee with "+id+" successfully removed";
	}
	
}
