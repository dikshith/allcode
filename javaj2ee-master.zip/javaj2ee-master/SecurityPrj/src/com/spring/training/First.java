package com.spring.training;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/first")
public class First {

	@Produces(MediaType.TEXT_HTML)
	@GET
	@Path("/{fname}/{lname}")
	public String getMessage(@PathParam("fname")String firstName,@PathParam("lname")String lastName)
	{
		return "<html><body><h2>Welcome TO REST "+firstName+","+lastName+"</h2></body></html>";
	}
	
	@Produces(MediaType.TEXT_PLAIN)
	@GET
	@Path("/msg")
	public String getNextMessage()
	{
		return "this is a plain message";
	}
	
	@Produces(MediaType.APPLICATION_XML)
	@GET
	@Path("/emp")
	public Employee getEmployee()
	{
		return new Employee(1, "Arvind", "Accountant");
	}
}
