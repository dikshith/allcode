package com.spring.training;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

public class GetClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Client client=ClientBuilder.newClient();
		String url="http://localhost:8080/JsonRestPrj/resource/emp/102";
		WebTarget target=client.target(url);
		
		Employee emp=target.request().accept(MediaType.APPLICATION_JSON).get(Employee.class);
		
		System.out.println(emp.getId()+"\t"+emp.getName()+"\t"+emp.getDesignation());
		
		String s=target.request().accept(MediaType.APPLICATION_JSON).get(String.class);
		System.out.println(s);
				
		
		
	}

}
