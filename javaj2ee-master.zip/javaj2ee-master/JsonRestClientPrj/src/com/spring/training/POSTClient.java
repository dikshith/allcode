package com.spring.training;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class POSTClient {
	public static void main(String[] args) {
		
		String url="http://localhost:8080/JsonRestPrj/resource/emp";
		Client client=ClientBuilder.newClient();
		WebTarget target=client.target(url);
		Employee e=new Employee();
		e.setName("Rajesh");
		e.setDesignation("Accountant");
		Response response=target.request(MediaType.APPLICATION_JSON).
				accept(MediaType.TEXT_PLAIN).
				post(Entity.json(e));
		System.out.println("Received Msg: "+response.readEntity(String.class));
		
		Employee e1=new Employee();
		e1.setName("Rajesh");
		e1.setDesignation("Accountant");
		response=target.request(MediaType.APPLICATION_XML).
				accept(MediaType.TEXT_PLAIN).
				post(Entity.xml(e));
		System.out.println("Received Msg: "+response.readEntity(String.class));
		
	}

}
