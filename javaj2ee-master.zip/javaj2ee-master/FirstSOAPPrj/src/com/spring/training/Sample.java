package com.spring.training;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public class Sample {
	
	@WebMethod
	public String getMessage(String name)
	{
		return "Welcome to WebService "+name;
	}

}
