package com.spring.training;

import javax.xml.ws.Endpoint;

public class PublishService {
	public static void main(String[] args) {
		Sample sample=new Sample();
		Endpoint.publish("http://localhost:3410/samp", sample);
		System.out.println("Webservice published");
	}

}
