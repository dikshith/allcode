package com.spring.training.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

public class SecureClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Client client=ClientBuilder.newClient();
		HttpAuthenticationFeature authenticationFeature=HttpAuthenticationFeature.basic("user1", "pass1");
		client.register(authenticationFeature);
		String url="http://localhost:8080/SecurityPrj/resource/first/Raja/Shekar";
		WebTarget target=client.target(url);
		
		String msg=target.request().get(String.class);
		System.out.println("Received Msg: "+msg);
		
	}

}
