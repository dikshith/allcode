package com.spring.training.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

public class XMLClient {
	public static void main(String[] args) {
		
		String url="http://localhost:8080/FirstRESTPrj/resource/emp/102";
		Client client=ClientBuilder.newClient();
		WebTarget target=client.target(url);
		Employee e=target.request().get(Employee.class);
		System.out.println(e.getId()+"\t"+e.getName()+"\t"+e.getDesignation());
		
	}

}
