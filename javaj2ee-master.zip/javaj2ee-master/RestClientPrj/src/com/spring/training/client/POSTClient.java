package com.spring.training.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

public class POSTClient {
	public static void main(String[] args) {
		
		String url="http://localhost:8080/FirstRESTPrj/resource/emp";
		Client client=ClientBuilder.newClient();
		WebTarget target=client.target(url);
		Employee e=new Employee();
		e.setName("Rajesh");
		e.setDesignation("Accountant");
		Response response=target.request().post(Entity.xml(e));
		System.out.println("Received Msg: "+response.readEntity(String.class));
		
		
	}

}
