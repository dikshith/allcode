package com.spring.training.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

@SuppressWarnings("unused")
public class DeleteClient {
	public static void main(String[] args) {
		
		String url="http://localhost:8080/FirstRESTPrj/resource/emp/102";
		Client client=ClientBuilder.newClient();
		WebTarget target=client.target(url);
		Response response=target.request().delete();
		System.out.println("Received Msg: "+response.readEntity(String.class));
		
		
	}

}
