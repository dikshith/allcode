package com.spring.training.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;

public class FirstClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Client client=ClientBuilder.newClient();
		String url="http://localhost:8080/FirstRESTPrj/resource/first/msg";
		WebTarget target=client.target(url);
		
		String msg=target.request().get(String.class);
		System.out.println("Received Msg: "+msg);
		url="http://localhost:8080/FirstRESTPrj/resource/first/Arvind/Shenoy";
		
		target=client.target(url);
		
		 msg=target.request().get(String.class);
		System.out.println("Received Msg: "+msg);
	}

}
