#!/bin/bash

while IFS= read -r line; do
    #echo "Text read from file: $line"
	if grep -q '()@' <<< $line ;	
		then
			#echo "Text read from file: $line"	
			RESPONSE_TIME=`awk -F '[][]' '{print $2}' <<< $line`
			STRING_IS=`awk -F '[][]' '{print $3}' <<< $line |grep "()@" |cut -d '@' -f1`
			echo "$STRING_IS" "--" "$RESPONSE_TIME"
	
	elif grep -q 'Select' <<< $line;
		then
			#echo "Text read from file: $line"
			RESPONSE_TIME=`awk -F '[][]' '{print $2}' <<< $line`
			STRING_IS=`awk -F '[][]' '{print $3}' <<< $line`
			echo "$STRING_IS" "--" "$RESPONSE_TIME"
	
	else
		echo "Pattern Match to be done more"	
	fi
	
done < "$1"
