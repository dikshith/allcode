
#!/bin/bash

while IFS= read -r line; do
    #echo "Text read from file: $line"
	if grep -q '()@' <<< $line ;	
		then
			#echo "Text read from file: $line"	
			RESPONSE_TIME=`awk -F '[][]' '{print $2}' <<< $line`
			STRING_IS=`awk -F '[][]' '{print $3}' <<< $line |grep "()@" |cut -d '@' -f1`
			echo "$STRING_IS" "--" "$RESPONSE_TIME"
			echo "Rest API Response time is : $RESPONSE_TIME"
	
	elif grep -q 'Select' <<< $line;
		then
			#echo "Text read from file: $line"
			RESPONSE_TIME=`awk -F '[][]' '{print $2}' <<< $line`
			STRING_IS=`awk -F '[][]' '{print $3}' <<< $line`
			echo "$STRING_IS" "--" "$RESPONSE_TIME"
			echo "SQL statement execution time is : $RESPONSE_TIME" 
	
	else
		echo "Pattern Match to be done more"	
	fi
	
done < "$1"


#!/bin/bash

while 

IFS= read -r line; do

if grep -i '()@' <<<$line;
then

IFS=' ' # space is set as delimiter
read -ra ADDR <<< "$str" # str is read into an array as tokens separated by IFS

for i in "${ADDR[@]}"; do # access each element of array
    echo "$i"
done
fi
	
done < "$1"	

match($0, /Rows=([0-9]+)/, matches)
rows = matches[1]

match($0, /Time=([0-9]+)/, matches)
time = matches[1]

print date_time, job_detail_1, job_detail_2, query,rows, time
}

{                                           
match($0, /\[([0-9]+.[0-9]+)\]+/)           
response_time = substr($0, RSTART, RLENGTH) 
                                            
match($0, /[ ](\w+)(\()\@)+, matches)              
job_detail_1 = matches[1]                   
                                            
print response_time, job_detail_1           
}                                           
                                            
											
{                                            
match($0, /\[([0-9]+.[0-9]+)\]+/)            
response_time = substr($0, RSTART, RLENGTH)  
                                             
match($0, /[ ](\w+)[(\()\@)+]/, matches)     
job_detail_1 = matches[1]

match($0, /[ ][(Select)][ ](\w+)/, matches)     
job_detail_2 = matches[1]                    
                                             
print response_time, job_detail_1 ,job_detail_2       
}

# URL for Shell Scripting - http://www.ict.griffith.edu.au/anthony/info/shell/general.txt
-------------------------------------------------------------------------------
          Hints and Tips for general shell script programing

Shell Tutorial Video for begineeres...
  http://ontwik.com/linux/shell-programming-for-beginners/

Fast cheat sheet
  curl cheat.sh/bash/:learn | less

-------------------------------------------------------------------------------
Shell Script Option Handling

#!/bin/sh
#
# script [options] args...
#
# The 'Usage()' and 'Help()' functions uses $PROGDIR to find this actual
# script, then reads and output these comments (short usage or full set of
# comments) as the documentation for this script.   That is the script
# commands and usage documention are in the same file, making it self
# documenting, via options.
#
# Options
#   -q    Be wery wery Quiet... We're hunting Wabbits
#   -v    Verbose Output
#   -d    Debugging Run
#   -n    Dry Run - Do Noth'n
###
#
# More Extensive Documentation can go here
#
######
#
# Programmers only docs, which are not output by Usage()
#
# Discover where the shell script resides
PROGNAME=`type $0 | awk '{print $3}'`  # search for executable on path
PROGDIR=`dirname "$PROGNAME"`          # extract directory of program
PROGNAME=`basename "$PROGNAME"`        # base name of program

# Fully qualify directory path (remove relative components and symlinks)
PROGDIR=`cd "$PROGDIR" && pwd -P || echo "$PROGDIR"`
ORIGDIR=`pwd -P`                       # original directory

Error() {  # Just output an error condition and exit (no usage)
  echo >&2 "$PROGNAME:" "$@"
  exit 2
}
Usage() {  # Report error and Synopsis line only
  echo >&2 "$PROGNAME:" "$@"
  sed >&2 -n '1,2d; /^###/q; /^#/!q; /^#$/q; s/^#  */Usage: /p;' \
          "$PROGDIR/$PROGNAME"
  echo >&2 "For help use  $PROGNAME --help"
  exit 10;
}
Help() {   # Output Full header comments as documentation
  sed >&2 -n '1d; /^###/q; /^#/!q; s/^#*//; s/^ //; p' \
          "$PROGDIR/$PROGNAME"
  exit 10;
}
Doc() {   # Output the full documentation comments
  sed >&2 -n '1d; /^######/q; /^#/!q; s/^#*//; s/^ //; p' \
          "$PROGDIR/$PROGNAME"
  exit 10;
}

# minimal option handling
while [  $# -gt 0 ]; do
  case "$1" in

  -\?|-help|--help) Help ;; # Standard help options.
  -doc|--doc)       Doc ;;

  -q) QUIET='quiet'     ;;  # be very very quiet - I'm hunting wabbit!
  -d) DEBUG='debug'     ;;  # Output programming debug reports
  -v) VERBOSE='verbose' ;;  # bang the drums, and blow the whistles

  -n) shift; NAME="$1"  ;;  # provide a name argument

  --) shift; break ;;    # forced end of user options
  -*) Usage "Unknown option \"$1\"" ;;
  *)  break ;;           # unforced  end of user options

  esac
  shift   # next option
done

  [ "$QUIET" ] || echo "I am just acting normal"
  [ "$DEBUG" ] && echo "$PROGNAME DEBUG: End of options"
  [ "$VERBOSE" ] && echo "I am hooting my horn and making a racket"

  [ "$NAME" ]  && echo "Using name $NAME"

-------------------------------------------------------------------------------
Special Option Handling Examples

=======8<--------
  echo "Input Arguments:"
  printf "    "
  printf "'%s' " "$0" "$@"
  echo ""
=======8<--------

=======8<--------
while [  $# -gt 0 ]; do
  case "$1" in

  # Standard help option.
  -\?|-help|--help) Help ;;
  -doc|--doc)       Doc ;;

  # Simple flag option
  -d|--debug) DEBUG=true ;;

  # Simple option and argument   EG: -n name
  -n) shift; name="$1" ;;

  # Option and argument joined   EG: -Jname
  -J) name=expr + "$1" : '-.\(.*\)'` ||
            Usage "Option \"$1\" missing required value" ;;

  # Joined OR unjoined Argument  EG:  -Nname  or  -N name
  -N*) Name=`expr + "$1" : '-.\(..*\)'`  || { shift; Name="$1"; } ;;

  # Name handling but can handle a "0" argument correctly
  # WARNING: if  -b0  is an posibility then you need to use this instead.
  # Otherwise it will think the value is unjoined when it isn't  Arrrgghhhh...
  -b*) bits=`expr + "$1" : '-.\(..*\)'`
       [ "X$bits" = 'X' ] && { shift; bits="$1"; }
       ;;

  # Number with type check     EG:  -{size}
  -[0-9]*)
      size=`expr + "$1" : '-\([0-9]*\)$'`  ||  Usage "Bad Number Option"
      [ "$size" -eq 0 ] && Usage
      Width=$size; Height=$size
      ;;

  # Numbers with type checks     EG:  -{width}x{height}
  -[0-9]*x[0-9]*)
      w=`expr + "$1" : '-\([0-9]*\)x'`          || Usage "Bad Geometry"
      h=`expr + "$1" : '-[0-9]*x\([0-9]*\)$'`   || Usage "Bad Geometry"
      [ "$width" -eq 0  -o  "$height" -eq 0 ] && Usage "Zero Geometry"
      geometry="${w}x${h}"
      ;;

  # Geometry style rectangle argument
  [0-9]*x[0-9]*)                     CROP="$1" ;;   # WxH
  [+-][0-9]*[+-][0-9]*)              CROP="$1" ;;   # +X+Y
  [0-9]*x[0-9]*[+-][0-9]*[+-][0-9]*) CROP="$1" ;;   # WxH+X+Y

  # Generalised Argument Save    EG: -Gvalue or -G value  =>  $opt_G
  -[a-zA-Z]*)   # what flags are we looking for
      var=`expr + "$1" : '-\(.\).*'`
      arg=`expr + "$1" : '-.\(..*\)'`
      [ "X$bits" = 'X' ] && { shift; arg="$1"; }
      eval "opt_$var"="\"\$arg\"" ;;
      ;;

  -)  break ;;           # STDIN,  end of user options

  --) shift; break ;;    # forced end of user options
  -*) Usage "Unknown option \"$1\"" ;;
  *)  break ;;           # unforced  end of user options

  esac
  shift   # next option
done

# Argument Count Check
[ $# -lt 2 ] && Usage "Too Few Arguments"
[ $# -gt 2 ] && Usage "Too Many Arguments"

# Handle normal arguments now...
FILE="${1:-/dev/stdin}"
[ ! -f $FILE ] && Error "Input \"$FILE\": does not exists"
[ ! -r $FILE ] && Error "Input \"$FILE\": is not readable"

# optional settings
# set http_cmd to use - if not already set
cmd_found curl && : ${http_cmd:=curl}
cmd_found wget && : ${http_cmd:=wget}
cmd_found lynx && : ${http_cmd:=lynx}

# debug echo function
if [ "$DEBUG" ];
then debug() { echo 2>&1 "$@"; }
else debug() { :; }
fi
debug Debugging has been enabled

-------------------------------------------------------------------------------
Dependency Program Testing

DEPENDENCIES="sed awk grep egrep tr bc magick"

# Check Dependencies a script requires is available
for i in $DEPENDENCIES; do
  type $i >/dev/null 2>&1 ||
    Usage "Required program dependency \"$i\" missing"
done

-------------------------------------------------------------------------------
Variable substitution

  ${var:-word}       # use var otherwise use 'word'
  ${var:+word}       # if var is non-null use 'word'  else nothing
  ${var:=word}       # assign var with 'word' if unset, then return var

  ${var+word}        # if var has been set use 'word'  else nothing
                     # this is the best way to test if a variable
                     # or array/hash element has been set (even is empty)
                     # EG:   [[ ${var+has_been_set} ]]

  ${var:offset}      # contain of var from offset to end (starts at 0)
  ${var:offset:len}  # only return len chars from offset (neg removes N chars)
                     # negatives (mean offset from end)
                     #   var=$( echo {a..z} | tr -d ' ' )
                     #   echo ${var:5:3}      # get 3 chars    'fgh'
                     #   echo ${var:0:-3}     # all but last 3 chars
                     #   echo ${var: -10:5}   # space needed   'qrstu'
                     #   echo ${var:(-10):5}  # parenthsis works too

  ${var#word}        # remove prefix 'word' start of string (may be glob!)
  ${var##word}       # use the longest matching prefix glob

  ${var%word}        # remove suffix 'word' from end of string (may be glob!)
  ${var%%word}       # use the longest matching suffix glob


  ${var/sub/repl}    # substr replace first occurance of 'sub' with 'repl'
  ${var//sub/repl}   # substr replace all occurances of 'sub' with 'repl'
  ${var/#sub/repl}   # substr replace 'sub' at start with 'repl'
  ${var/%sub/repl}   # substr replace 'sub' at end with 'repl'
                     # the '/repl' is optional if you just want to remove sub
                     # see the start of "file.txt" for examples
                     #   ${file//-/_}  # substitute all '-' for '_'

  ${var^}            # output var with first char uppercased
  ${var,,}           # output var with everything lowercased
                     # ^ uppercase   , lowercase   ~ swap upper-lower

-------------------------------------------------------------------------------
test or '['  vs  '[['

'[' is legacy but works with older shells, and thus more compatible scripting.
However as it was based on a command, it is executed like it is a command
and arguments will need to be quoted.  While [[ is a builtin expression,
so aruments do not need quoting.

Because of this the two tests execute different code to do simular tasks.

For example
  b='/*'
  [ $b ] && echo true || echo false     # ERRORS  too many arguments
  [ "$b" ] && echo true || echo false   # quoting makes it work
  [[ $b ]] && echo true || echo false   # expression has no problems

Note the last is true for any, non-empty, value of b

Also '[[' has some extra features like =~ regular expressions (see below)
And can have different syntax.  For example it uses && instead of -a

NOTE: ((..)) and $((..)) is for mathematics not testing!

-------------------------------------------------------------------------------
GLOB Glob glob matching

  x*          will match files and output those starting with 'x', sorted
  [zyx]*      will match files and output in sorted x,y,z order!
  {z,y,x}*    will output strings in that specified order (unsorted)
              That is it is just iterated though the given sequence

  In all cases if the glob does not match, the original string is returned
     echo no_file_*
     no_file_*

  Using curly braces, also includes sequences (forward or backwards)
     echo {A,Z,B}{4..2}
     A4 A3 A2 Z4 Z3 Z2 B4 B3 B2
     echo {C..H}
     C D E F G H
  You can not mix numbers and letters for a curly brace sequence
     echo {0..F}
     {0..F}
  Nor can you use commas with a sequence
     echo {0..9,A}
     0..9 A

Bash...
Globs in conditional testing.  Do not use quotes for the glob!

  name=abcd
  [[ "$name" = a* ]] && echo true || echo false
  true

  name=xyz
  [[ "$name" = a* ]] && echo true || echo false
  false

  [[ "$name" != a* ]] && echo true || echo false
  true

-------------------------------------------------------------------------------
Variable Testing

Rules of thumb when using [ ... ]
  * Always quote all variables being tested (unless in a builtin)
  * Only use the boolean type test (below) when
        you have complete control of all posible settings.
  * Prepend X (or other alphanumberic) when comparing unknown strings.
  * Don't use ! if you can avoid it (too many changes between shells)

Boolean Variable tests (variable contents must be fully controlled)...
     var="true"   # var is true
     var=""       # var is false
     [ "$var" ]    && echo 'var is true'
     [ -n "$var" ] && echo 'var is true'
     [ -z "$var" ] && echo 'var is false (empty)'
     [ "${var+set}" ] && echo 'var has been set (may be empty)'


  Giving it a more verbose setting works better for -x tracing...

     FLAG="FLAG_IS_TRUE"
     if [ -n "$FLAG" ]; then
       ...

Test of variables containing ANY string  (see PROBLEM CASES below)
To do this prefix the strings with something like 'X'
     option=-xyzzy
     [ "X$option" != X ]    && echo option is defined (not null)
     [ "X$option" = 'X-f' ] && echo "option is '-f'"
     [ "X$a" = "X$b" ]      && echo "$a equals $b"

PROBLEM CASES...

These cases cause the "[...]" tests to fail badly!

  [ $var ]           # but  var="a = b"   (return false instead of true)
  [ "$var" ]         # but  var=-a  (actually any option starting with '-')
  [ "$a" = "$b" ]    # but  a='('  and   b=')'  (works in bash)

This is why you must use the string test above (with 'X' prefixes).

NOTE  test ! ...  differs from UNIX to UNIX
Under BASH, it is the NOT of the next 3 arguments that follow (non-sensible).
Under Solaris SH, it seems to handle precedence correctly.

EG:   test "" -a ! ""    is false as you would expect under BASH
BUT   test ! "" -a ""    is true for BASH   and   false for Solaris SH

-----------

BASH: Newer shells has a [[..]] that overcomes these problems
quoting and contents does not matter!

  var="true"   # var is true
  var=""       # var is false

  ${#var}          length of var     0 = empty/unset/false
  [[ -v var ]]     var has been defined (set) regardless of value
  [[ $var ]]       var has been defined and is not null
  [[ -n $var ]]    ditto
  [[ -z $var ]]    var is undefined or empty
  [ "$a" = "$b" ]

-------------------------------------------------------------------------------
Is a variable defined or set (empty or otherwise)

For simple variables you can use [[ -v var ]]
It knows the difference between unset and empty.

But using '[' it can be done, just not easily

Variable substition test (works with older shells)...

  # Using of defined substition test....
  if [ "X${var+defined]}" ]; then
    echo "Variable is defined"
  fi

Using a array element count (BASH or ZSH)...

  if [ ${#var[@]} -eq 0 ]; then
    echo "Variable undefined, or Array/Hash is Empty"
  elif [ "X$var" = "X" ]; then
    echo "Variable is a NULL string"
  else
    echo "Variable has non-null value of \"$var\""
  fi

  # The first test cannot be used for testing a specific array element,
  # which may be sparse arrays (undefined elements between defined elements).

Sparse Array...

  array[5]="element"

  [[ -v array[3] ]] && echo "array[3] is set" || echo "array[3] not set"
  [[ -v array[5] ]] && echo "array[5] is set" || echo "array[5] not set"

  [ "${array[3]+set}" ] && echo "array[3] is set" || echo "array[3] not set"
  [ "${array[5]+set}" ] && echo "array[5] is set" || echo "array[5] not set"

  array[5]=""    # and repeat tests

Associative Array or Hash

  unset hash;
  declare -A hash
  hash[set]=""

  [[ -v hash[not] ]] && echo "hash[not] is set" || echo "hash[not] not set"
  [[ -v hash[set] ]] && echo "hash[set] is set" || echo "hash[set] not set"

  [ "${hash[not]+set}" ] && echo "hash[not] is set" || echo "hash[not] not set"
  [ "${hash[set]+set}" ] && echo "hash[set] is set" || echo "hash[set] not set"

-------------------------------------------------------------------------------
Integer Shell Mathematics

Also see "apps/printf.txt" especially with regards to handling numbers that
may have leading zeros (which BASH treats as octal).

EG:
   printf "%d\n" 013            # -> "11"
   printf "%d\n" $((10#013))    # -> "13"

---
EXPR....
This is the traditional way (integer)
all elements must be separate arguments,
and special characters like '*' (for multiply) must be escaped.

  expr + 5 / 2
  2

---
BASH...

In BASH you can use some special constructs (no $ variable prefix needed)
Specifically  ((...))  for conditionals (EG: exit code testing)
             $((...))  for variable substitution.
             let var=  for assignment
NOTE: do not confuse this with $(...) for command substitution

WARNING: $[...] is an older math expression construct and is depreciated due
to its confusion with [...] and [[...]] string/file handling conditionals.

  a=1
  if (( a == 0 )); then  echo true; else echo false; fi

  a=5 b=2
  echo $(( a/b ))
  2

Using a built-in integer maths is many orders of magnitude faster.
BUT as BASH and not compatible with older Bourne shells (on older machines)
The "expr" command is not a built-in, and has some problems (see below).

  time for I in $(seq 1 1000); do A=$((1+1)); done
  real    0m0.009s

  time for I in $(seq 1 1000); do expr 1 + 1 > /dev/null; done
  real    0m1.330s

---
KSH...

The [[...]] was introduced by ksh88 as a [...] replacement and should
be used for string comparisons, while ((...)) are for numerical comparisons.
You can still use [...] for the older traditional test command in ksh88
BASH inherited this convention form KSH.

-------------------------------------------------------------------------------
Floating Point Math....

Also see "apps/printf.txt" especially with regards to handling numbers that
may have leading zeros (which BASH treats as octal).

BC

NOTE: BC outputs without decimal places by default...

  echo 5/2 | bc
  2

BC Scaling will add decimal places (fixed point integer math)

  echo 'scale=5; 5/2' | bc
  2.50000

  math() {   # math function using bc
    echo "scale=5; $1" | bc
  }

BC with a -l flag (true floating point and math functions)
This also enables scaling precision (scale=20)

  echo 5/2 | bc -l
  2.50000000000000000000

  # a() is arctan  so a(1)*4 => PI
  echo 'a(1)*4' | bc -l
  3.14159265358979323844

---
ImageMagick...

It is a rather long winded, but if you are already working with images...
It also syntax checks the arguments so only a quote taint check is needed.

  convert null: -precision 10 -format '%[fx:atan(1,1)*4]' info:
  3.141592654

  math() {   # math function using imagemagick
    convert xc: -print "%[fx: $1 ]\n" null:
  }
  math '5/2'
  2.5

---
Awk / Perl

WARNING this requires arguments to be taint checked for safety,
as the string substitution be easily 'hacked' to do other things.

  awk 'END{ print 5/2 }' /dev/null
  2.5

  perl -e 'print 5/2, "\n"'
  2.5


-------------------------------------------------------------------------------
Expr fails if you try to match using a keyword like "match","index" "substr"

WARNING: expr is not a built-in but is backward compatible

This works reasonably well - most of the time

    word=abcde
    expr "$word" : ".\(.*\)"
    bcde

But WILL fail is word is a "expr" keyword

    word=match
    expr "$word" : ".\(.*\)"

    word=index
    expr "$word" : ".\(.*\)"
    0

    word=substr
    expr "$word" : ".\(.*\)"
    expr: syntax error

Using "expr match" with the word "match" will also fail

    word=match
    expr match "$word" ".\(.*\)"
    expr: syntax error

The problem is "match" is a keyword, which confuses "expr" argument parsing.

The solution is to always start "expr" with '+' and use the older ':' form

    word=match
    expr + "$word" : ".\(.*\)"
    atch

    word=index
    expr + "$word" : ".\(.*\)"
    ndex

An alturnative and more portible solution for this specific expression is to
modify the expression so the input never can match a keyword

    word=match
    expr "x$word" : "x.\(.*\)"
    atch

This Cavat can be very important for ALL expressions, NOT just a string
test.

---
MacOsX "expr" using "match" however will fail (old version of expr)

   expr match "this_is_a test" 'this'
   expr: syntax error

You must use the ':' sub-string test instead

   expr "this_is_a test" : 'this'
   4

Unfortunatally adding the '+' to the start also fails Arrggghhhh....

   expr + "this_is_a test" : 'this'
   expr: syntax error

Best idea is modify the expression using the portible technique shown above

    word="this_is_a test"
    expr \( "x$word" : "xthis" \) - 1
    4

-------------------------------------------------------------------------------
Bash regular expression matching (in [[ ]] )
Also useful for spliting up strings

Globbing
  name=abcd
  [[ $name = a* ]] && echo true || echo false
  true

NOTE: the RE must NOT be quoted!
Any part that is quoted in the RE must be an exact match to the string.

  if [[ "start-abc-ijk-xyz-end" =~ -(.*)-(.*)-(.*)- ]]; then
    echo "BASH_REMATCH = \"$BASH_REMATCH\""
    echo "BASH_REMATCH[*] = ${BASH_REMATCH[*]}"
  fi

  BASH_REMATCH = "-abc-ijk-xyz-"
  BASH_REMATCH[*] = -abc-ijk-xyz- abc ijk xyz

BASH_REMATCH is an special built-in array
0 = the string the expression matched  (equivelent to sed: \&)
n = positional sub-expression          (equivelent to sed: \1 \2 .. \N )

Remember the first element of the array is the same as the normal varable
which is the whole of the matching part.


The best way to solve quoting issues is to put the pattern in a variable

  string="start-123-456-789-end"
  pattern="-(.*)-(.*)-(.*)-"

  [[ $string =~ $pattern ]] &&
    echo "BASH_REMATCH[*] = ${BASH_REMATCH[*]}"

  BASH_REMATCH[*] = -123-456-789- 123 456 789

The positional sub-expressions are number by parentesis, so repeating
the sub-expressions will only return that last match, from the overall
matching expression.

  string="start-123-456-789-end"
  pattern="(-[^-]*-)*"
  [[ $string =~ $pattern ]] &&
    echo "BASH_REMATCH[*] = ${BASH_REMATCH[*]}"

  BASH_REMATCH[*] = -123-456-789- -789


There is no 'before' or 'after' match provision, unless '^' or '$' is included
Also minimal matching is not provided, each expresion will gobble as much of
the string as it can, so you need to craft your RE very carefully.

  string="to-be-or-not-to-be"
  pattern="^([^-]*)-(.*)-(.*)"

  [[ $string =~ $pattern ]] &&
    echo "BASH_REMATCH[*] = ${BASH_REMATCH[*]}"

  BASH_REMATCH[*] = to-be-or-not-to-be to be-or-not-to be

-------------------------------------------------------------------------------
Verbose Log Handling

  # Set a flag (see variables above)
  verbose=verbose_true

  # direct test variable and echo
  [ "$verbose" ] && echo "I am being verbose"


  # log() functional doing the verbose test
  log() { [ "$verbose" ] && echo "$@"; }
  log "I am being verbose"


  # Remove multiple 'if' tests
  if [ "$verbose" ]; then
    log() { echo "$@"; }
  else
    log() { :; }
  fi
  log "I am being verbose"


  # Colapsing Function (function redefines itself on first call)
  # The "$verbose" variable can now be defined LATER,
  # as long as it is done before its first use
  log() {
    if [ "$verbose" ]; then
      log() { echo "$@"; }
    else
      log() { :; }
    fi
    log "$@"
  }
  log "I am being verbose"

-------------------------------------------------------------------------------
Inverted TR compatibility problems

WARNING: The command acts very differently with regards [...] and character
ranges between older solaris machines and linux.

On Solaris 5.8,
  tr -cd '[a-z]' deletes all characters except abcdefghijklmnopqrstuvwxyz
  tr -cd 'a-z'   deletes all characters except a, z, and hyphen.

On Linux (gnu),
  tr -cd '[a-z]' deletes all characters except a to z and brackets
  tr -cd 'a-z'   deletes all characters except a to z.


-------------------------------------------------------------------------------
Argument Sorting By Shells

When the order of the arguments being processed is important.

All shells normally sort the output of any commands with meta characters.
Also "ls" will sort its arguments again internally, while "echo" will not.

EG compare the output of these commands

     echo b* a*             # sorted b  then sorted a - word based
     echo [ba]*             # totally sorted output   - word based
     echo {b,a}*            # sorted b  then sorted a - word based

     ls -d b* a*            # totally sorted output   - line based
     ls -d {b,a}*           # totally sorted output   - line based

The "ls" sorts its output regardless of the input so a's are always output
before b's.  Also if two arguments match, that match is output twice.

Echo however relies on the shell meta-expandion so its output is based on the
shell sorting of arguments.  Seperate arguments remain seperate. And the '{}'
meta-characters generate seperate aruments before the '*' meta is applied.

As such  {b,a}* ->  b*  a*  Thus generate two separated sets of arguments.

This has been tested and works as described in  csh, tcsh, bash, and zsh
NOTE: 'dash' does not have '{}' functionality.

-------------------------------------------------------------------------------
Positional Parameter Argument Handling...

If you care for the possibility that there aren't any arguments.
    "$@"         ->    ""     (one empty argument)
    ${1+"$@"}    -> nothing at all
This is not a problem with newer modern shells, only very old Bourne shells.
Check by looking at the $# variable.

You can index command line arguments using substring expansion.

  set -$- a b c d e f

Note @ isn't a full bash array
  echo "$3"
  c
  echo "${@[3]}"
  -bash: ${@[3]}: bad substitution

But you can 'slice' it as an array...

  echo "${@:3:1}"            # Get argment 3
  i=3; echo "${@:$i:1}"      # Get argment 3 indirectly by index
  echo "${@:$i}"             # Get argment 3 and later

  echo "${@: -1}"            # Get the last argument (NOTE THE SPACE!)
  echo "${@:(-1)}"           # get the last argument alternative
  echo "${@:${#@}}"          # get last argument alternative

  echo ""${@:1:($#-1)}       # All but the last argument

  set -$- "${@:1:$(($#-1))}" # pop (and lose) the last argument

  ARGS=( "$@" )              # Convert arguments into a full bash array

  printf "'%s' " "${@:0}"    # If a offset of 0 is given "$0" is included
                             # So this output the full command and arguments

This is different to 'arrays' (see later) for historical reasons.
But slices can be used with arrays -- see below.

-------------------------------------------------------------------------------
Auto change shells on brain dead systems (Ultrix)

On this machie "sh5" has more features (like functions) than "sh".
So if the script is likely to run on such a system, adding this gives you
better functionality.

  #!/bin/sh -
  #
  # Check the type of shell that is running (For Ultrix)
  [ "x$1" != 'x-sh5' -a -f /bin/sh5 ] && exec /bin/sh5 -$- "$0" -sh5 "$@"
  [ "x$1" = 'x-sh5' ] && shift
  #

-------------------------------------------------------------------------------
Checking for a numerical value

Built-ins only...

    case "$var" in
        '' | *[!0-9]*)  echo "non-numeric" ;;
        *)              echo "numeric" ;;
    esac

ASIDE: This can also be used for simple IP argument testing by adding a '.'!

Using egrep...

    echo "$arg" | egrep '^[0-9]+$' >/dev/null || echo "not-numeric"

Using expr. (fails for 'zero' input, or some strings).

    expr match "$var" '\([0-9]*\)$' || echo "not a non-zero-numeric value"

-------------------------------------------------------------------------------
Command search (bash)

 1/ REDIRECTION is done (before anything else!)
 2/ simple alias expandsion
 3/ Parameter expansion, command substitution, arithmetic expansion,
    and quote removal,  variable assignment performed if '=' found.
 4/ functions exectuted
 5/ shell built-in commands
 6/ lookup command in hash table  (error hash lookup does not exists)
 7/ search the command PATH variable
 8/ else error "Command not found"

-------------------------------------------------------------------------------
One line if-then-else shell command

   cmd1 && cmd2 || cmd3

This however will execute cmd3 if EITHER cmd 1 or cmd2 fails!
If cmd2 never fails (IE "echo" ) - no problems

This means a status check can be written as

   command && echo TRUE || echo FALSE

-------------------------------------------------------------------------------
Results from commands

  a=`command`

  a=$(command)

Quotes are not needed, unless appending other things, but does not hurt

Split result into words...

  read -r a b c < <( echo one two three )
  echo "a=\"$a\"   b=\"$b\"   c=\"$c\""

  This is Equivelent to the use of a pipline using a named pipe (bourne sh)

    mknod -p cmd_pipe
    echo one two three > cmd_pipe &
    read -r a b c < cmd_pipe
    rm -f cmd_pipe
    echo "a=\"$a\"   b=\"$b\"   c=\"$c\""

You can also directly read into a bash array (sequential)...
  array=( $( echo one two three ) )

Split by column (read comma separated CSV file)
Warning: more than 3 columns will merg into $c,
This will also fails with regard to quoted commas!

  OIFS=$IFS IFS=','
  while read a b c
  do
    echo "LOGIN:$a LASTNAME:$b FIRSTNAME:$c"
  done < fileA.csv

Read results line by line

  { read -r line1
    read -r line2
    read -r line3
  } < <( command )

For array of lines...
  unset arr i
  while read -r; do
    arr[i++]=$REPLY
  done < <(your command)
  # Now get any final line that has no final newline (may be empty)
  [[ $REPLY ]] && arr[i++]=$REPLY

The above can now be done using mapfile (bash)
  mapfile arr <(your command)

NOTE: "read" will return FALSE, if the last line did not end in a newline
IE: From a file without a final newline.   See "info/shell/input_reading.txt"

-------------------------------------------------------------------------------
Break string into words...

Bourne shell "set" method with IFS save.  (Only shell built-ins!)
WARNING: this replaces script/function args. (Dangerious)
(NOTE: no quote in the 'set' - making it very dangerious security-wise)

  line="one two three"
  set -- $line
  a="$1"
  b="$2"
  c="$3"
  echo "# a=\"$a\"   b=\"$b\"   c=\"$c\""
  # a="one"   b="two"   c="three"

Using IFS to change separator character

  line="one:two:three"
  OIFS=$IFS; IFS=":"; set -- $line; IFS="$OIFS"
  a="$1"
  b="$2"
  c="$3"
  echo "# a=\"$a\"   b=\"$b\"   c=\"$c\""
  # a="one"   b="two"   c="three"


sed/awk/grep  -- to separate variable assignments
Very slow - but can extract values from very complex lines in any order.
Basically you read ALL the input into a variable then extract what you want.

  line="one:two:three"
  a=`echo "$line" | awk -F: '{print $1}'`
  b=`echo "$line" | awk -F: '{print $2}'`
  c=`echo "$line" | awk -F: '{print $3}'`
  echo "# a=\"$a\"   b=\"$b\"   c=\"$c\""
  # a="one"   b="two"   c="three"

OR
  line="one:two:three"
  a=`echo "$line" | sed 's/:.*//'`
  b=`echo "$line" | sed 's/.*:\(.*\):.*/\1/'`
  c=`echo "$line" | sed 's/.*://'`
  echo "# a=\"$a\"   b=\"$b\"   c=\"$c\""
  # a="one"   b="two"   c="three"


Bash 'here string' reading  (Safer - Bash built-ins only)

  var="one two three"
  read -r a b c <<< "$var"
  echo "# a=\"$a\"   b=\"$b\"   c=\"$c\""
  # a="one"   b="two"   c="three"

---
With field separators, including blank fields...

  IFS=":" read -r a b c <<< "hello::world"
  echo "# a=\"$a\"   b=\"$b\"   c=\"$c\""
  # a="hello"   b=""   c="world"

or you can pre-process the line so you can skip fields
at start middle or end

  read -r a b c <<< $(echo "::hello::world::" | tr ':' ' ')
  echo "a=\"$a\"   b=\"$b\"   c=\"$c\""
  # a="hello"   b="world"   c=""

The last can be simplified to read command output more directly...

  read -r a b c  < <( echo "::hello::world::" | tr ':' ' ' )
  echo "a=\"$a\"   b=\"$b\"   c=\"$c\""
  # a="hello"   b="world"   c=""

WARNING: IFS normally allows multiple spaces between fields (whitespace).
But if it is not the whitespace default setting, then the fields are assumed
to be separated by exactly one character.

As such in one example above $b is a empty string!  (Awk is similar)
BUT in if mapped to white space, $b is not empty and $c is empty

-------------------------------------------------------------------------------
LIST functions (plain Bourne Shell)
(Also usable for PATH-like environment variables)
NOTE the use of sub-shells (...) to scope the IFS setting

  list="a:b:c:d"               # list variable
  element="e"                  # element of the list
  sep=":"                      # list_seperator (not used, and not white space)

  Append to list (even if empty!)
      list="${list:+$list$sep}$element"

  Split up list
      function split_list () {
        ( IFS="$sep"
          set -- $list
          for f in "$@"; do
            echo -n "${f:-.} "
          done; echo
        )
      }

  Loop over list
    for item in `( IFS="$sep"; echo $list; )`; do
      echo item=$item
    done

  Count of elements
    count=`IFS="$sep"; set - $list; echo $#`

  get I'th element (shell must understand shift argument)
    element=`IFS="$sep"; set - $list; shift $I; echo $1`

  get first element
    element=`IFS="$sep"; set - $list; echo $1`

  delete first element
    #list=`echo "$list" | sed "/$sep/"\!"d; /:/s/^[^$sep]*$sep//;"`
    list=`echo "$list" | cut -d"$sep" -f2-`

  delete specific element over the whole list -- not right???
    list=`echo "$list" | sed "s|${element}${sep}||g; s|${sep}${element}\$||;"`

Of course BASH arrays superseeds all this.

-------------------------------------------------------------------------------
Indirect Variables and De-Referance

setup
  a=123
  b=a
  set_ABC_var=987
  set=ABC

# Bourne shell
  eval "echo \$$b"
  eval "echo \${$b}"
  eval "echo \${set_${set}_var}"

# Bash (version 2)
  echo "${!b}"
  var="set_${set}_var"
  echo "${!var}"          # the variable must be the full reference

  # NOTE: do not confuse this with
  # echo "${!X*}"
  # which will LIST all variables starting with 'X', and not a reference them

-------------------------------------------------------------------------------
Bash Arrays

Also see http://mywiki.wooledge.org/BashFAQ/005

NOTES:
  * Indexes start at zero
  * The zeroth element is the same as the variable of the same name.
  * Elements do not need to exist (sparse array) but are "" if referenced,
  * Referencing an undefined element, does NOT define the element.

Pre-delcaring an array (not actually needed)

    declare -a xyz[50]

Basic

   letters=( a b c d e z )      # just define in sequence

   letters[6]=f                 # add/change a element

   echo "${letters[4]}"         # referencing an element
   echo "${letters[-2]}"        # negative references from end

   echo "${letters[@]}"         # list all elements

   echo ${#letters[@]}          # number of elements

   args_array=( "$@" )          # Convert arguments into an array

   # Does not seem to work!
   keys="${!letters[@]}"        # list the keys as an array
   echo ${#keys[@]}             # number of keys

Array slices (array-substring slices)

   echo "${letters[@]:3:2}"     # list elements 3 and 4 (c and d)

   echo "${letters[@]: -1}"     # list last element (NOTE THE SPACE)
   echo "${letters[@]:(-1)}"    # list last element alternative

   # see Positional Parameters on using this with arguments.

Read file into an array

   words=( $(cat file) )        # you do not need to worry about quotes
                                # or [#] in the file. Due to quote order

   mapfile lines                # see "file.hints" reading files
   echo "${lines[@]}"           # number of lines


Append onto existing array

    list=( "${list[@]}" "new_element" "another_element" )

Copy Array

    new_array=( "${old_array[@]}" )  # removes any 'undefined' elements


The zeroth element is the same as the variable name without the index.

    variable[0]=zero
    echo $variable
    zero

    variable=different
    echo ${variable[0]}
    different

    echo ${#variable}        # length of zeroth element (0=unset or null)
    8

----
Sparse Array Handling

    sparse[4]="y"                 # create sparse array of values
    sparse[7]="n"
    sparse=( [4]="y" [7]="n" )    # alternative method (equivelent)

    sparse[13]=''                 # add a null value in sparse array
    sparse[22]=last               # add another parameter

    echo ${sparse[4]}             # get a specific value
    y

    k=7
    echo ${sparse[k]}             # offset as an arithmetic expansion
    n

    sparse[k]=q                   # subsitute value
    echo ${sparse[k]}
    q


    echo ${#sparse[@]}            # number of defined elements
    4                             # this is not the last element index

    echo "${sparse[-1]}"          # output the last element ('last')
    last
    unset sparse[-1]              # unset last element
    echo "${sparse[-1]}"          # last element 'q'
    sparse[22]=last               # readd last element

    echo "${sparse[@]:5:3}"       # list next 3 items after index 5
    q  last                       # note the extra space in output for
                                  # index 13 which is a empty string.
                                  # Note count ignores undefined elements
    echo "${sparse[@]:14:1}"      # lists the next defined element from 14 on!
    last                          # This is actually element 22!


    echo "${sparse[3]+defined}"      # Not defined!
    echo "${sparse[3]-not_defined}"  # Not defined!

    echo "${sparse[-5]+defined}"  # Not defined!

    echo "${sparse[13]+defined}"  # Is defined!
    echo "${sparse[13]}"          # But also empty string!


Defined Elements

    echo "${sparse[13]+element 13 is defined}"
    element 13 is defined

    echo "${sparse[14]-element 14 is not defined}"
    element 14 is not defined
    # WARNING element value will be printed otherwise!

    # Test if a specific index is defined
    [ "${sparse[13]+defined}" ] && echo true || echo false
    true
    [ "${sparse[14]+defined}" ] && echo true || echo false
    false

Compress Sparse Array

    sparse=( [4]=y [7]=q [13]='' [22]=last )
    compress=( "${sparse[@]}" )   # compress array indexes - no longer sparse

    echo ${#sparse[@]}            # Number of defined elements
    4
    echo ${#compress[@]}
    4

    echo ${!sparse[*]}            # what indexes are in use
    4 7 13 22
    echo ${!compress[*]}
    0 1 2 3

    echo ${compress[3]}           # what is the last (number-1) element
    last
    echo ${compress[-1]}          # alternative
    last


Is it a sparse array -- we need a better way

    sparse=( [4]=y [7]=q [13]='' [22]=last )
    indexes=(${!sparse[*]})       # array of indexes
    echo ${indexes[*]}            # indexes used by the sparse array
    4 7 13 22
    echo ${indexes[-1]}           # get index of last argument in sparse
    22

    # compare  number of elements  with  index of last element
    if [ ${#sparse[@]} -ne ${indexes[-1]} ]; then
      echo array is sparse
    fi
    array is sparse


Loop through Arrays

    sparse=( [4]=y [7]=q [13]='' [22]=last )

    echo "${sparse[@]}"           # list all parameters (quoted)
    y q  last                     # Note the extra space for the NULL element

    for i in "${sparse[@]}"; do   # loop through elements
      echo "'$i'"
    done
    'y'
    'q'
    ''
    'last'

    for i in ${!sparse[*]}; do    # list using indexes to elements
      echo "$i : '${sparse[i]}'"
    done
    4 : 'y'
    7 : 'q'
    13 : ''
    22 : 'last'


Specific Element Handling

    sparse=( [4]=y [7]=q [13]='' [22]=last )
    echo ${#sparse[22]}           # Length of a specific element
    4

    test_element() {
      if [ "${sparse[$1]+is_defined}" ]; then
        # NOTE: Null string tests are always true on undefined elements!
        # So you had to test if defined before testing for null or empty
        if [ "${sparse[$1]:+not_null}" ]; then
          echo "defined and not null, with length ${#sparse[$1]}"
        else
          echo "defined but is null (empty string)"
        fi
      else
        echo "is not defined"
      fi
    }

    test_element 12
      is not defined

    test_element 13
      defined but is null (empty string)

    test_element 22
      defined and not null, with length 4


Stack Array... (using the first element as a stack count)

  INITIALISE
    unset stack                # initialise or reset (no number, until used)
    stack=0                    # initialize with a actual number of elements
                               # can be empty for the same effect.

  PUSH
    stack[++stack]="e$stack"   # PUSH some value onto end
                               # (repeat this a few times)

  SIZE
    echo $stack                # number of elements on stack (array length-1)

  POP
    echo ${stack[stack]}       # Get top element (or a null value)
    unset stack[stack--]       # remove top element from stack!
                               # no underflow limit (0 returned, then nulls)

  LIST STACK
    echo "${stack[@]}"         # get stack size and elements


  SIMPLISTIC POP
    # WARNING: element is not actually removed!
    # A pop on a empty stack returns '-1' and it slowly goes wrong!
    # NOT RECOMMENDED, unless overflow protection added.
    echo ${stack[stack--]}     # get and pop top element


Bash 4.2 Array Stack should be able to do away with the count
as "${stack[-1]" references the top most element,
but assignment interaction seems to prevent that usage.

Stack Alternative (stores in top to bottom sequence)
   http://www.tldp.org/LDP/abs/html/arrays.html#STACKEX
This provides functions with limit protections


Sort an array (shell built-ins only)

=======8<--------
#!/bin/bash
i=0
for n in "$@"; do
  a[i++]="$n"
done

# Bubble Sort Array

for (( i=0; i<(${#a[@]}-1);  i++ )); do
  for (( j=i+1; j<(${#a[@]}); j++ )); do
    if [[ ${a[j]} < ${a[i]} ]]; then
      t=${a[j]};
      a[j]=${a[i]};
      a[i]=$t;
    fi
  done
done

# Output the array
echo "${a[@]}"

=======8<--------

-------------------------------------------------------------------------------
Bash Associative Array (Hash) Example

WARNING: They MUST be declared!

# From Bash v4 on you can use associative arrays....

typeset -A homedir    # Declare associative array
homedir=(             # Compound assignment
    [jim]=/home/jim
    [silvia]=/home/silvia
    [alex]=/home/alex
)
homedir[ormaaj]=/home/ormaaj # assign another single element

# Enumerate all indices (user names)

for user in "$((homedir[@]))"; do
    printf 'Home directory of user %s is: %q\n' "$user" "${homedir[$user]}"
done

Note: when used in ((..)) you need to backslash the $ of the index.
https://github.com/koalaman/shellcheck/wiki/SC2149

  # Regular array
  index=42
  echo $((array[index]))

  # Associative array
  index=banana
  echo $((array[\$index]))

Does a key exist (even if empty)
  [ "${myArray['key_or_index']+key_is_present}" ] && echo present

-------------------------------------------------------------------------------
builtin cat command

This cat only uses the shell builtins! As such can be used on a machine
which has no access to shared libraries and nothing but the statically
linked bourne sh can run.

   shcat() {
     while test $# -ge 1; do
       while read -r i; do
         echo "$i"
       done < $1
       shift
     done
   }

Of course the real cat command is only as big as it is, to protect the
user from himself and to provide a huge number of options.

PS:  If the "ls" command is also not available then you can use

    echo *

For directory listings, using only builtins. Though this will not tell
you if files are executables or sub-directories, or handle problems like
spaces in filenames, or unprintable characters.

-------------------------------------------------------------------------------
The useless use of 'cat'!

You often see in shell scripts...

      cat input_file | some_command

The cat is useless as it is exactly the same as

      some_command < input_file

Or even

      < input_file some_command

Without needing to fork the extra "cat" process or creating a pipeline.
However it is sometimes useful to do anyway to make the code more readable.
Particularly in long pipelines, or where "some_command" is a large while loop.

WARNING: "some_command" will be executed as a sub-shell in the first instance,
but is part of the main-shell in the second instance.

-------------------------------------------------------------------------------
Non-POSIX shell bug...

    foo=non-postix
    while read line; do
       foo=postix
    done < /etc/passwd
    echo "foo = $foo"

You should get the output "foo = postix".

But some bad (old) shell implementations redirecting a file into a control
structure will use a sub-shell for that structure.  As such in many old shells
you will get a output of "foo = non-postix"

The POSTIX standard forbids this behaviour.

----
Piped Loop Shell Bug

HOWEVER: Pipelines into sub-shells IS still a problem!!!

    foo=nothing
    echo "testing 1 2 3" |
    while read line; do
       foo=something
    done
    echo "foo = $foo"

You will get "foo = nothing" as the 'while' was in a sub-shell.

One solution is to use 'named pipes' technique such as

A POSIX shell solution is to use a named pipe

  mkfifo mypipe
  foo=nothing
  echo "testing 1 2 3" > mypipe &
  while read line; do
    foo=something
  done < mypipe
  echo "foo = $foo"
  rm mypipe

Bash can also use builtin named pipes
NOTE <(...) is a file name and still needs a extra < to pipe it in

  foo=nothing
  while read line; do
    foo=something
  done <  <(echo "testing 1 2 3")
  echo "foo = $foo"

See http://mywiki.wooledge.org/BashFAQ/024

See also co-processes.hints
  http://www.imagemagick.org/Usage/info/shell/co-processes.hints
on bi-directional I/O to a background process, daemon, or internet service.

-------------------------------------------------------------------------------
Newlines in Command Substitutions...

Note that  var=`cmd` will save the newline characters (quotes not needed)
But to use them you must quote the variable!

    :::> m=`mount | awk '{print $1}'`;
    :::> echo $m
    / /usr /home

    :::> echo "$m"
    /
    /usr
    /home

In otherwords outside quotes, newlines in the input are treated purely
as white space between arguments and thus ignored. Inside quotes
newlines are retained as newlines.

-------------------------------------------------------------------------------
Inserting a complex command line inside a shell script...

For example embedding, sed, awk or perl scripts in a shell script.

The normal way is to use Single Quotes around the command line script.
For Example...

    awk '# add prefix to lines
         { print "prefix> " $0 }
        ' list.txt

Note the whole script is inside single quotes on the nawk command line!

ASIDE: old versions of awk must have something on the first line thus the
addition of the # comment to keep it happy!  Perl needs no such comment but
does require a -e option to execute a command line argument.


Environment Variables

Both "awk" and "perl" can read environment variables for data passing.

    export column=2
    awk 'BEGIN    { column = ENVIRON["column"] }
         /^[^#]/  { print $column }
        '  file


Insert a Shell variable in quoted code...

To include an external shell variable, you need to switch quote modes
just for that variable...

    file="list.txt"
    awk '# add prefix to lines
      { print "'"$file"'> " $0 }
      ' "$file"

For awk you can declare the variable on the command line,

    file="list.txt"
    awk -v file="list.txt" '# awk code
      { print file "> " $0 }
      ' "$file"

OR
    file="list.txt"
    awk '# awk code
      { print file "> " $0 }
      ' file="$file"  "$file"

Note the latter may or may not have the 'file' variable available to
the BEGIN block.

----
Single Quote Insertions...
There are a number of ways...

    awk '# print single quotes
      BEGIN {
         print "'\''"
         print "\047"
         q="\047"; print "Can or can" q "t?"
         exit
      }'

The first print in the above works for any command line script.
The rest are "awk" (or whatever) dependant.

You can also use the special  $'...'  form of single quote delimited strings
which is specific BASH and KSH, (ansi-c style quoting).  That is force all
backslashed escapes to be performed.   EG: All backslashes are handled
as be the ANSI-C compilion of strings.  EG:  \n \t \' \" all handled.

    echo $' single_quote=\'  double_quote=\" '

CAUTION: Watch for single quotes inside COMMENTS in the script code block!
The comments are within the single quotes so are scanned for those quotes.



Alternative Method for code blocks in shell scripts.

Perl has the added advantage that you can pipe the command to execute into
it.  For example using a 'herefile'

perl  <<'EOF'
print "Hello, world from perl in a here document.\n";
EOF

Of course you have less control over the escaping and addition of external
variables and values into the script.
Also see HERE files in  "info/shell/file.hints"

CSH SCRIPTS: If you must do this in a csh script (don't do it!), you will need
to escape (backslash) the new line at the end of every line, even though
single quotes are being used.  Also watch out for history escapes '!' which
in csh work inside single quotes!


-----------

Warning: Some precautions are necessary with the contents of the
variable, as the inserted value will be parsed by the command
(awk/sed/perl/etc..).


In perl characters than may need special handling include
  $  @  "  '  \  and so on.

A better method may be to 'pipe' the variable into the command
For example this works...

encode() {    # WWW url encoding (typically needed for passwords)
  echo -n "$1" |
    perl -e '$_ = <>; s/[^\w.]/sprintf "%%%02x",ord $&/eg; print;'
}


The more direct method (below) will fail on characters such as
'@' or '$' or '"'  in the inserted variable (perl quoting rules)

encode() {    # WWW url encoding (typically needed for passwords)
  perl -e '$_ = "'"$1"'"; s/[^\w.]/sprintf "%%%02x",ord $&/eg; print;'
}

This is especially important for 'tainted' input data.

-------------------------------------------------------------------------------
Is COMMAND available

There is two techniques available to test if a command is available.
The first is to use the `status' return of the "type" or "which" command
of the shell you are using. The Second is to examine the output of that
command itself.

Using status return.
  This is a simple method of testing the existence of a command.
  But DOES NOT WORK ON ALL SYSTEMS!  The problem is that old shells
  (For Example: SunOS Bourne sh) always returns a true status weather
  the command is present or not!

  Bourne Shell

     if  type COMMAND >/dev/null 2>&1; then
        # COMMAND is available
     fi


  C-Shell

  Warning: The "which" command in  C shell is not a builtin but a external
  script which sources your .cshrc (YUCK). As such the Bourne shell alias
  is preferred which will only search your current command PATH.

    if ( ! $?tcsh ) then
     alias which 'sh -c "type \!:1 2>&1"'
    endif

    if ( -x "`which COMMAND >/dev/null`" ) then
      # COMMAND Available
    endif

  TC-Shell

  Tcsh 6.06 also does not return the correct status in its which
  command. Use it like the csh which above.

  WARNING: this method will also test positive for :-
    subroutines, bash aliases, and probably other non-command definitions.


Examine output
  The other am more reliable method is to examine the output of the
  "type" or "which" command to looks for the string "not found" (See
  below).  This is more complex than the above status check but should
  work on ALL unix machines regardless of age.

  Bourne Shell

    cmd_found() {
      case "`type $1 2>&1`" in *'not found'*) return 1 ;; esac; return 0
    }
    # ...
    if  cmd_found COMMAND; then
      # COMMAND is available
    fi

    # WARNING: Do not use...
    cmd_found COMMAND &&
       COMMAND args &
    # As it leaves behind a waiting sub-shell


  C-Shell & Tcsh   (See notes below)

    if ( ! $?tcsh ) then
      alias which 'sh -c "type \!:1 2>&1"'
    endif
    ...
    if ( "`which less`" !~ *'not found'* ) then
      # COMMAND Available
    endif


  NOTES for "which/type" commands :-

  The above methods look for the specific string  "not found"
  This is important as the sh  type command  and tcsh which command
  produce different output, and this may also vary from bourne shell
  to bourne shell or other shell types.

  Csh  -- "which" is an unreliable shell script!
          fudge it into a shell script "type" command.
          See the "Which Problem" below.

  Tcsh
    > which less
    /opt/bin/less
    > which junk
    junk: Command not found.
    > which which
    which: shell built-in command.
    > alias a alias
    > which a
    a:  aliased to alias

  Solaris Bourne shell
    $ type less
    less is /opt/bin/less
    $ type junk
    junk not found
    $ type type
    type is a shell builtin
    $ func(){ echo ha; }
    $ type func
    func is a function
    func(){
    echo ha
    }


   Solaris Ksh
     As per Sh, but the actual function definition is NOT listed

  Bash
    $ type less
    less is /opt/bin/less
    $ type junk
    bash: type: junk: not found
    $ type type
    type is a shell builtin
    $ func(){ echo ha; }
    $ type func
    func is a function
    func ()
    {
        echo ha
    }
  NOTE: bash also has a type -t which responds with a single word "file",
  "alias", "function", "builtin", "keyword", or nothing if command does not
  exist.  A -p will print the disk file name, or nothing. A -a prints all the
  places that have that name.

From the results above, only the appearence of  "not found" in the false
statement is consistant.  But only when the result is not a bourne shell
function, which presumably replaces the real-command of that name.


The Expanded Bourne shell form, without using the "cmd_found" function is as
follows, But is is a low simpler and easier to read if you use the funtion.

  If command present

    if  expr + "`type COMMAND 2>&1`" : '.*not found' == 0 >/dev/null;  then
      # COMMAND is available
    fi

  and its inverse (not present)

    if  expr + "`type COMMAND 2>&1`" : '.*not found' >/dev/null;  then
      # Comand is NOT present
    fi

  finally only using built-in commands...

    case "`type COMMAND`" in
      *'not found'*) # Command not found ;;
      *)             # Command found ;;
    esac

  Functional forms
    cmd_found() {
      expr + "`type $1 2>&1`" : '.*not found' == 0 >/dev/null
    }
  OR
    cmd_found() {
      case "`type $1 2>&1`" in *'not found'*) return 1 ;; esac; return 0
    }

Final form


=======8<--------
# Is the command available?
case `type cmd_found 2>&1` in *'not found'*)
  cmd_found() {
    case "`type "$1" 2>&1`" in *'not found'*) return 1 ;; esac; return 0
  } ;;
esac
=======8<--------

This lets you export the funtion declaration using
   declare -fx cmd_found # export this function!

-------------------------------------------------------------------------------
CSH Which problem!

On SunOS:

The which command is a csh script that specifically reads the .cshrc
file to find out about aliases. To avoid having .cshrc do lots of odd
things to your script, use the following form.

  set program = `/bin/env HOME= /usr/ucb/which $program`

This is NOT a problem in Tcsh, where "which" is a built-in.

The best solution it to replace "which" with the bourne shell "type" command
in C shells but leave it alone for TC shells.

  if ( ! $?tcsh ) then
     alias which 'sh -c "type \!:1 2>&1" | sed "s/.* is //"'
  endif

  set program = `which $program`

-------------------------------------------------------------------------------
echo without a return (bsd & sysV)

# echo without a return (bsd & sysV)
if [ "x`echo -n`" = "x-n" ]; then
  echo_n() { echo ${1+"$@"}"\c"; }
else
  echo_n() { echo -n ${1+"$@"}; }
fi


For Csh or Tcsh (which you shouldn't use for scripts anyway)

# echo without a return (bsd & sysV)
if ( "x`echo -n`" == 'x-n' ) then
  alias echo_n 'echo \!:* "\c"'
else
  alias echo_n 'echo -n \!:* '
endif


For all shells, but uses non-builtin commands

  echo '----- Press return to continue. ' | tr -d '\012'

-------------------------------------------------------------------------------
Print a line of N repeated characters

This is weird but it works...
    awk 'BEGIN{$79=OFS="*";print}'


Function method - no newline...
    function char_repeat(){
      for x in $(seq $2); do
        echo -n "$1"
      done
    }

    char_repeat '*' 76; echo ""

    echo "<-`char_repeat '-O-' 22`->"


-------------------------------------------------------------------------------
Looping
and Generation of a list of numbers

Bourne Shell while loop

   limit=10; n=1;
   while [ $n -le 10 ]; do
     echo $n;
     n=`expr $n + 1`;
   done


with number formatting (printf)

   limit=10; n=1;
   while [ $n -le $limit ]; do
     printf %03d $n;
     n=`expr $n + 1`;
   done

NOTE: printf will repeat its output if too many arguments are given
   printf '%05d\n' {1..10}


with number formating (sed truncation)
NOTE: number of . in final parenthesis is the final size
But this will fail if number is larger

  limit=10; n=1;
  while [ $n -le $limit ]; do
    echo "000000$i"
    i=`expr $i + 1`
  done |
    sed 's/.*\(...\)$/\1/g'


Bash allows a C-like for loop...
   for (( i=1; i<=10; i++ )); do
     echo $i;
   done

Note: That both the  shell "while" and the Bash "for (( ; ; ))" method will do
a final incrment of the variable, before exiting.  That means after the loop
you can get some idea if the loop completed, or a "break" was used.  Only on
completion will the number be larger than the range {end}.

All bets are off however if the index number is modified inside the loop to
cause the break. OR a "for .. in" loop is used instead (see below)

Bash (versions > 3.2) - not the case for MacOSX
    echo {5..15}                       # forward can be negative numebrs
    5 6 7 8 9 10 11 12 13 14 15

    echo {15..5}                       # reverse order
    15 14 13 12 11 10 9 8 7 6 5

    echo {5..15..2}                    # increment supported in BASH v4.0+
    5 7 9 11 13 15

    echo {x..z}                        # single letters (only single letters)
    x y z

    echo {c..a}{A..C}                  # or letter sequence (multiple expand)
    cA cB cC bA bB bC aA aB aC


    echo {1..3}{,}                     # duplicate the output
    1 1 2 2 3 3


    echo {{1..5},{23..27}}             # brace expandsions nest
    1 2 3 4 5 23 24 25 26 27

  Formatted.

    echo {0007..11}
    0007 0008 0009 0010 0011

    printf "__%d__"  {1..5}; echo ""   # printf auto-loops multiple args
    __1____2____3____4____5__



  WARNING: you can not use variables in this syntax!

  This for example it will NOT work ...   {1..$limit}
    limit=5
    echo {1..$limit}

  Using eval substitution will work (painful though it is)...
    echo $(eval echo {1..${MAX_SEGMENTS}})

  You better of using a "for( ; ; )" loop!



Awk
  awk "BEGIN {for (i=1;i<$COUNT;i++) {printf(\"%03d\n\",i)} }"

Perl
   perl -le 'for(1..10){print}'


Dev Zero -into-> newlines -into-> cat line counting
Specifically    dd | tr | cat
This reads 10 (or however many) 'nulls' from /dev/zero, then
converts that into 10 return characters, which cat numbers,
finally any non-return white space is removed.

   dd 2>/dev/null if=/dev/zero bs=10 count=1 | tr \\0 \\012 |\
     cat -n | tr -d '\40\11'


seq
  The Gnu "seq" command is the simplest and most wide spread...
  Args:  {start} [[{incr}] {end}]
  Note that {incr} is in middle which is logical but can be awkward.
    seq 10
    seq 5 10
    seq 10 -1 1
    seq 1 .1 2
    seq -f %03g 5 5 100
As you can see it can go forwards, from any range, with any increment,
even backwards, or using factions (floats), and with format control.

WARNING: "seq" is not available under MacOSX  :-(
See 'seq' replacement function below (and in my scripts area)


multi_seq (personal script) handles multiple ranges of numbers
  ISO dates
    multi_seq "%d-%02d-%02d"  2010,2011  12  31
  Human dates
    multi_seq -f "%02d/%02d/%d"  31  12  2010,2011



shuf
  Will randomly shuffle numbers
    seq 9 | shuf         # 3 8 6 1 4 7 2 9 5


jot
  It seem "jot" can also be used, but it is not a standard install in fedora.
  The first number by default is the total number of numbers wanted
  spread out equally accross the range given (even floating point)
    jot 3                # 1 2 3
    jot 2 12             # 12 13
    jot 3 12 16          # 12 14 16
    jot 4 12 17.0        # 12.0 13.7 15.3 17.0
    jot -p4 4 12 17.0    # 12.0000 13.6667 15.3333 17.0000
  Using '-' will let it work more like "seq" using args: {start} {end} {incr}
    jot - 2 10 2         # 2 4 6 8 10
  It can create random numbers
    jot -r 5 1000 9999   # 3435 1811 2641 7472 2528
  or repeat a specific word or string
    jot -b word 3        # word word word




DIY seq() replacements

# SIMPLE:        seq_count {end}
#
seq_count() {
  i=1; while [ $i -le $1 ]; do echo $i; i=`expr $i + 1`; done
}

# INTERMEDATE:   simple_seq {start} {incr} {end}
#
simple_seq() {
  i=$1; while [ $i -le $3 ]; do echo $i; i=`expr $i + $2`; done
}

# ADVANCED:      simple_integer [-f format] [{start} [{incr}]] {end}
#
# almost perfect but only with increasing intergers
seq_integer() {
    if [ "x$1" = "x-f" ]
    then format="$2"; shift; shift
    else format="%d"
    fi
    case $# in
    1) i=1 inc=1 end=$1 ;;
    2) i=$1 inc=1 end=$2 ;;
    *) i=$1 inc=$2 end=$3 ;;
    esac
    while [ $i -le $end ]; do
      printf "$format\n" $i;
      i=`expr $i + $inc`;
    done
  }

# float_seq  --- FUTURE (when needed)

See also "Columns of Data" (below) for more examples...

------------------------------------------------------------------------------
Arrays of Numbers

You can make an array say   A-1 to  C-3  easilly in bash using

  echo {A..C}-{1..3}
  A-1 A-2 A-3 B-1 B-2 B-3 C-1 C-2 C-3

Or using "multi-seq"
  multi_seq "%X_%d" 0xa,0xc 3 | tr '\n' ' '; echo
  A_1 A_2 A_3 B_1 B_2 B_3 C_1 C_2 C_3

You can even add prefix or postfix strings

  echo s {A..C}-{1..3} e
  s A-1 A-2 A-3 B-1 B-2 B-3 C-1 C-2 C-3 e

But what if you want a prefix/postfix string around each row
that gets a lot more complicated...

Lets make this a bit clearer, so as to make working it out easier

  echo Array \
     ' s' A-{1-3} 'E ' \
     ' s' B-{1-3} 'E ' \
     ' s' C-{1-3} 'E ' \
     End
  Array  s A-{1-3} e  s B-{1-3} e  s C-{1-3} e End

So we need to reproduce that by merging the lines
  echo Array \
       '" s" '{A..C}'_{1..3} "e "' \
       End
  Array " s" A_{1..3} "e " " s" B_{1..3} "e " " s" C_{1..3} "e " End

And evaluate it
  eval echo Array \
       '" s" '{A..C}'_{1..3} "e "' \
       End
  Array  s A_1 A_2 A_3 e   s B_1 B_2 B_3 e   s C_1 C_2 C_3 e  End



-------------------------------------------------------------------------------
Columns of Data

column
  On linux to just put the data into columns use "column"
  But you don't get good control of the number of columns.
  (-c is width of the page)

  Example: seq 13 | column -c40
  Outputs:  1       4       7       10      13
            2       5       8       11
            3       6       9       12

  Or across the page...

  Example: seq 13 | column -x -c40
  Outputs: 1       2       3       4       5
           6       7       8       9       10
           11      12      13

  This can also format text tables using "-t" function of column to preserve
  the line by line column structure of the input file.

     column -s: -t /etc/group

  OR a more complex example...

     ( echo "PERM LINKS OWNER GROUP SIZE MONTH DAY HH:MM NAME"; \
       ls -l | tail -n+2; \
     ) | column -t

  Warnings:
   * Tabs are used.  Use the "expand" filter to remove (before & after).
   * It also does not work as well as should
     As it makes all columns equal width
     EG: compare the output of   "ls"  and "ls | column"
   * No easy way control the final number of columns
   * Any meta-characters found may cause column silently ABORT,
     truncating the file being processed!

pr
  To convert a file (or part of a file) to VERTICAL ordered columns.
  Warning: this program will truncate data to fit into space available!

  Down the columns (like ls)
      pr -3 -t -l3
          |     `-- lines per column (very important to give correctly)
          `-------- number of columns
    if output width is a problem add a line width -w80

  Example file:  numbers 1 - 10, one number per line
  It is recomended that the -# be the first option.

    Example: seq -f %02g 10 | pr -3 -t -l4 -w30
    Output: 01        05        08
            02        06        09
            03        07        10
            04

  WARNING: Extra data may appear out of place

    Example: seq -f %02g 10 | pr -3 -t -l3 -w30
    Output: 01       04       07
            02       05       08
            03       06       09
            10

  For Across row sorting you can use "pr" with one-line 'pages'.

    Example:  seq -f %02g 10 | pr -t -l1 -3 -w30
    Output: 01        02        03
            04        05        06
            07        08        09
            10

paste
  simple, across ordered, tabs columns
    paste - - -
      Number of - given determines number of columns (tab separated)

    Example: seq -f %02g 10 | paste - - -
    Output: 01       02       03
            04       05       06
            07       08       09
            10

xargs
  simple, across ordered, unformated
    seq 13 | xargs -n 3 echo
    Output: 1 2 3
            4 5 6
            7 8 9
            10 11 12
            13

  Feed to column -t to re-align columns
    seq 13 | xargs -n 3 echo | column -t
    Output: 1   2   3
            4   5   6
            7   8   9
            10  11  12
            13

  You can also wrapped the output with start and end
    seq 13 | xargs -n 3 sh -c 'echo -- "$@" --;' sh
    -- 1 2 3 --
    -- 4 5 6 --
    -- 7 8 9 --
    -- 10 11 12 --
    -- 13 --


perl Array::PrintCols
  You can also use a NON-STANDARD perl module (from CPAN)

    seq -f %03g 100 |\
      perl -MArray::PrintCols -e '@a=<>; chomp @a; print_cols \@a'

perl DIY
  Otherwise manually handle columns in perl
  This reads all the data in first, but does not examine data widths.
  Outputs in row order, and is very manual

  Example:
    seq 13 |\
      perl -e '  @a=<>; chomp @a;
          my $columns = 4;
          my $i = $columns;
          foreach ( @a ) {
             print("\n"),$i=$columns  unless $i;
             printf "  %4s", $_;   $i--;
          } print "\n"; '
  Output:    1     2     3     4
             5     6     7     8
             9    10    11    12
            13

-------------------------------------------------------------------------------
Column Extraction

cut
   Extract columns from a file in terms of character separated fields
   or by character position.  Does not handle 'white space separated'
      cut -f3 -

colrm
   Remove unwanted columns of text from the file, in terms of character
   positions.

   "cut" and "colrm" are the inverse of each other.

join
   Extract white space seperated fields from one file
   For example 3rd field  (from file1 or stdin, file2 is /dev/null)
      join -a1 -o1.3 - /dev/null

awk
   Extract columns either by whitespace or character separators.
   can also process the feilds in other ways.
     awk '{print $3}' -

perl
   Can basically handle anything. (just need to work it out)
      perl -peF  'print $F[2],"\n";'


vim visual blocks (Ctrl-V)

-------------------------------------------------------------------------------
Remove all blank lines
This is simple...

  Vim
    :%g/^\s*$/d

  perl -ne 'print unless /^$/'
  perl -lne 'print if length'
  perl -ne 'print if /\S/'

-------------------------------------------------------------------------------
Compress multiple blank lines into one line.

NOTE: You may need to first remove white space on otherwise blank lines.
Typically removing all trailing whitespace from lines will do this.

This is not easy, as we want to preserve a blank line, removing extras.
Two basic techniques: print paragraphs, or delete extra blanks.

  cat -s    # will do this (if available)

  perl -00pe0

  perl -ne 'if (/\S/) { print; $i=0 } else {print unless $i; $i=1; }'

  perl -ne 'print if /\S/../^\s*$/'

  awk '{ printf "%s ", $0 } NF == 0 { print "\n" }' filename

  sed '/./,/^$/!d'          # no blank lines at top, one at bottom
  sed '/^$/N;/\n$/D'        # one blank at top, no blank lines at bottom
  sed '/[^ \t]/,/^[ \t]*$/!d'  # For blank lines with spaces and tabs

  # This one keeps one blank line at top and bottom if they are present
  sed ':x;/^\n*$/{N;bx;};s/^\(\n\)*/\1/'

  # Line joining in the vim editor!  as a macro
  :map QE  :$s/$/\\rZ/<CR>:g/^[ <TAB>]*$/,/[^ <TAB>]/-j<CR>Gdd
  or       :%s/\n\s*\n\(\s*\n\)*/\r\r/

See also   https://www.gnu.org/software/sed/manual/html_node/cat-_002ds.html

-------------------------------------------------------------------------------
Multi-line Paragraph to Single-line Paragraph

Most text files including this one consists of paragraphs of multiple lines
seperated by a blank line.  This converts those to single-line paragraphs that
are becomming more and more common.

Convert all paragraphs into a single line (blank line seperated)

    sed '/^$/d; :loop y/\n/ /; N; /\n$/! b loop;  s/   */ /g; s/^ //; s/ $//'

Also remove blank lines between paragraph lines

    sed '/^$/d; :loop N; s/\n$//; T loop; y/\n/ /; s/   */ /g; s/^ //; s/ $//'

WARNING: Better space handling is probably needed, especially for a last
paragraph that has no final blank line after it.

-------------------------------------------------------------------------------
Limit Line Length (replace with ...)

   sed -u 's/\(.\{77\}\).*/\1.../'

-------------------------------------------------------------------------------
One word per line

This is typically used for pre-processing for text formatting (see next)
or as part of a word-diff type utility (see: "info/apps/word-diff").

  cat file | sed 's/[^[:alnum:][:space:]]/\\&/g' | xargs -rn1 echo

The 'sed' in the above is to quote non-alphabetrical characters.
To remove punctuation too, delete the '\\&' form the above
Note paragraph blank lines are also removed.

ASIDE: Removing '[:space:]' is the accepted way of handling return delimited
line input into "xargs" safely.  The better way is to use -0 filename listing
format.

-------------------------------------------------------------------------------
Word-Wrapping or Text Formatting
Single-line Paragraphs to Multi-line Paragraphs

WARNING: There are two parts to doing this, spliting long lines and join
short lines.


vim has built in formating...
   gg}gqGgg}


Usually you would use "fmt" or "fold" which is a standard addition for LINUX
systems.

   fmt -u -w 72

NOTE: fmt preserves the indentation of the lines...

   fold -s -w 72 [file...]

NOTE: fold does not do the join operation on multi-line paragraphs!
The solution is to convert paragraphs to single-lines first.

  expand < file |
    sed '/^$/d; :loop y/\n/ /; N; /\n$/! b loop;  s/   */ /g; s/^ //' |
      fold -s -w 72

This replaces fold with a poor mans word-wrap...
It first joins all lines, then adds markers at line breaks,
and finally used "tr" to split lines AFTER 55 characters.

  expand < file |
    sed '/^$/d; :loop y/\n/ /; N; /\n$/! b loop;  s/   */ /g; s/^ //' |
      sed 's/ $/@/; s/[^@]\{55\} /&@/g' |
        tr '@' '\012' | sed 's/^/    /'

Note the second sed command wraps on a space AFTER '55' characters.
As such it can be fooled by very very long words.
True word wrap, splits on the space before the given column limit.

In "gnu-sed" you can replace '@' with '\x01'  and in "tr" use  '\001'
so as to avoid matching existing substitution characters in the text.

A variation to prevent matching existing characters, is to first remove all
extra spaces including those at the start and end of line, then treat
double-spaces as the paragraph break.

  expand < file |
    sed 's/  */ /g; s/^ //; s/ $//;' | tr '\012' ' ' |
      sed 's/ $/@/; s/   */@@/g; s/[^@]\{55\} /&@/g' |
        tr '@' '\012'

Perl Text Format (using the standard Text::Wrap module)

   #!/bin/perl
   use Text::Wrap  qw(&wrap $columns, $huge);
   $columns=72;
   $huge='overflow';
   ($/, $\) = ( '', "\n\n");   # read and output mutli-line paragraphs
   while(<>) {
     s/\s*\n\s*/ /g;           # remove newlines and indents
     print wrap('', '', $_);   # format paragraph
   }


Using xargs!  The number is column limit + 5 for the "echo "
NOTE: This only handles a single paragraph, but does BOTH the joining and
spliting of the lines.

  expand < file |
    sed 's/[^[:alnum:][:space:]]/\\&/g' | xargs -r -s 85 echo

It can also be used in perl, and indentation is easilly added.
NB: -r (no run if empty) is not available under solaris "xargs".

   system("echo '@list' | xargs -s 70 echo '    ' ");


-------------------------------------------------------------------------------
Capitalize the first word in string

The initial solutions in the news group came out to more than 10 lines of code!

    # Ken Manheimer   (expr-tr-expr)  -- see Expr Warning
    Word=`expr + "$word" : "\(.\).*" | tr a-z A-Z``expr + "$word" : ".\(.*\)"`

    # Paul Falstad    (cut-tr-sed)
    Word=`echo $word|tr a-z A-Z|cut -c1``echo $word|sed s/.//`

==> # Logan Shaw     (cut-tr-cut)
    Word=`echo "$word" | cut -c1 | tr [a-z] [A-Z]``echo "$word" | cut -c2-`

    # Harald Eikrem (sed only)
    Word=`echo $word | sed  -e '
            h; 'y/abcdefghijklmnopqrstuvwxyz/ABCDEFGHIJKLMNOPQRSTUVWXYZ/;
            G; 's/\(.\).*\n./\1/; ' `

    # Tom Christiansen  (perl)
    Word=`echo $word | perl -pe 's/.*/\u$&/'`

    # Jean-Michel Chenais <Jean-Michel.Chenais@epfl.ch>
    # (korn shell built-ins only)
    typeset -u W;typeset -l w;W=${word%${word#?}};w=$W;Word=$W${word#${w}}

    # perl of course makes this easy
    perl -e 'print "\u'"$word"'"'

-------------------------------------------------------------------------------
Suppressing the shell background fork message

The trick is to redirect the standard error output of the _shell_ itself

  Korn (with loss of standard error)
     ( command & 2>&3 ) 3>&2 2>/dev/null

  csh/tcsh (this appears to work)
     ( command & )

  bourne shell does not give a message about background forks ever.

The real problem is doing this without loosing the stderr of the command

  BASH

  This works.
    ( command & )

  But on older BASH you can use this...
    ( command 2>&5 & ) 5>&2 2>/dev/null


For example...

  This produces extra forking JUNK..
    ( echo "stdout"; echo "stderr" >&2; ) &
    [1] 29886
    stdout
    stderr
    [1]+  Done                    ( echo "stdout"; echo "stderr" 1>&2 )

  This does not
    ( ( echo "stdout"; echo "stderr" >&2; ) & )
    stdout
    stderr

-------------------------------------------------------------------------------
Getting environment from CSH startup scripts...

The trick is to process the startup scripts in a sub-shell
and then extract the resulting environment.

   env - DISPLAY=$DISPLAY HOME=$HOME TERM=dumb \
     csh -cf 'set prompt="> ";
              source .cshrc; source .login;
              echo "#------ENVIRONMENT------"
              env' |
       sed -n '/#------ENVIRONMENT------/,$p'

WARNING: Scripts may have other 'side-effects',
for example set permissions, create directories, etc., etc.

This technique has been used by other scripts, that were then found to
become problems due to such side-effects.

-------------------------------------------------------------------------------
Am I a Non-Interactive Shell

bourne sh:
  if [ -z "$PS1" ]; then   # script/remote execution (non-interactive)
csh:
  if ( ! $?prompt ) then   # script/remote execution (non-interactive)

In the bourne shell a better way is to test the shell options ``$-''
for the interactive flag directly.

  case $- in
    *i*) ;;   # do things for interactive shell
    *)   ;;   # do things for non-interactive shell
  esac

-------------------------------------------------------------------------------
Auto Background a shell script
  #!/bin/csh -f
  if ( $1:q != '...' ) then
    ( $0 '...' $*:q & )
    exit 0
  endif
  shift
  ...rest of script to run in background...

OR
   #!/bin/sh
   foreground stuff
   ( ( background stuff
   ) & )
   exit

-------------------------------------------------------------------------------
Background Remote Processes

A remote command leaves lots of `extra' processes to hold a
communications channel open for IO. The following will background the
remote shell and completely close the IO channel of the rsh command.

Csh on remote machine
  rsh machine -n 'command >&/dev/null </dev/null &'

Sh on remote machine
  rsh machine -n 'command >/dev/null 2>&1 <&1 &'

Either Shell or other shell
  rsh machine -n '/bin/sh -c "exec command >/dev/null 2>&1 <&1" &'

-------------------------------------------------------------------------------
Loop until parent process dies

Background tasks have an annoying habit of continuing to run AFTER you have
logged out. This following example program looks up the launching parent
process (typically your login shell) and only loops if the parent process is
still alive.

WARNING: The PS command varies from UNIX system to UNIX system so you will
have to tweek the arguments to the `ps' command to make this script work on
your UNIX system


=======8<--------
#!/bin/sh
#
# Loop until parent dies
#
sleep_time=300     # time between background checks

# Pick the appropriate ps options for your UNIX system
# Uncomment ONE of the following lines
#job_opt=xj; sep="";  ppid=1;   # SunOS
 job_opt=xl; sep=" "; ppid=4;   # Solaris
#job_opt=xl; sep=" "; ppid=4;   # IBM UNIX (aix)
#job_opt=xl; sep=" "; ppid=4;   # SGI UNIX (irix)

# Discover the parents process ID
set - `ps $job_opt$sep$$ | tail -n+2` "1"
eval parent=\$$ppid

# While parent is still alive
# The  kill command "-0" option checks to see if process is alive!
# It does NOT actually kill the process (EG: test process)
while  kill -0 $parent 2>/dev/null; do
  # ...
  # Do the background job here
  # ...
  sleep $sleep_time
done

# Parent process has died so we also better die.
exit 0
=======8<--------

Also see the script   ~anthony/bin/scripts/hostspace
as an example of a shell script for multiple hosts

-------------------------------------------------------------------------------
Setting a timed alarm in shell
   This can be done (as a background task) exactly how is an another matter
As an educated guess probably something like..

   # Trap the USR1 signal
   trap "do timeout commands" 16
   ( sleep $timeout; kill -16 $$; ) &

See also  "Command Timeout" (next).

-------------------------------------------------------------------------------
Command Timeout

Run a command but kill it if it runs for too long. This prevents scripts
hanging on a command, especially network related commands, like nslookup.

Another good summery of this is http://mywiki.wooledge.org/BashFAQ/068
though this was developed independantally.

Simple C solution...
  Look at ~/store/c/programs/timeout.c  which will timeout a command
  simply and easilly.  A lot better than the complex solutions below.
  But of course it is binary, so does not work on all systems.

  A advanced version is on linux systems in /usr/bin/timeout

  There is a "timeout" program written in shell.
       ~/store/scripts/command_run/timeout_bad
  It does a looped sleep to do interval testing, as such may not instantly
  return when a command finishes.  Also while it works fine from the command
  line it fails when used within a shell script!


The following are my attempts to build it in shell!
And shows just what a pain it can be.

---- Attempt 1 ----
Simply runs the command in the background and waits for it to
complete. A sleep command provides a timeout.

Works but full timeout period is always waited before exiting

  TIMEOUT=60  # timelimit for command
  ( command_which_can_hang &
    sleep $TIMEOUT; kill $! 2>/dev/null
  )

The above will wait for the sleep for the full TIMEOUT period, regardless of
how fast the command completes.  If the command is known to never finish then
the above will be fine!

For example..  at 3 in the afternoon, play random noise for 10 seconds
The 'cat' normally would never end, so will never abort early.
The sleep will time out the never ending command.

   > at 3pm
   cat /dev/urandom > /dev/dsp &
   sleep 10; kill $!

As a test try this...
   sleep 1
   cat /dev/urandom > /dev/dsp &
   sleep 1; kill $!


---- Attempt 2 -----
Works for modern day shells...

Example: NFS quota can hang, (so can any network command!)

=======8<--------
QUOTA_TIMEOUT=5

do_quota() {
  # lookup the users disk quota but with a timeout
  quota -v "$@" &            # output to stdout
  command_pid=$!             # get its pid (to terminate)
  ( trap "exit 1" 1 2 3 15   # be quiet if terminated
    sleep $QUOTA_TIMEOUT
    echo >&2 "Quota Timeout"
    kill -9 $command_pid
    exit 0
  ) &
  timeout_pid=$!             # pid of the timeout process
  wait $command_pid
  status=$?
  kill $timeout_pid
  exit $status
}
quota=`do_quota $USER`

=======8<--------

The problem here is that this works fine but the sleep will still continue
for the full timeout period. Basically the parent has no simple way of
killing the sleep that was lanched in the sub-shell, and does nto die
naturally.

This is not a problem if the sleep is not too long, it does not use
any resources other than a entry in the process table.


---- Attempt 3 ----
Kill the timer sleep too!

This is amost exactly the same, but also ensures the timer sub-process
cleans up the sleep if it is still running.

=======8<--------
DNS_TIMEOUT=5

do_nslookup() {
  # lookup the users disk quota but with a timeout
  nslookup "$@" | sed -n 's/Address: *\(.*\)/\1/p' &
  command_pid=$!  # get its pid (to terminate)

  # run a timer to abort the above command
  ( trap 'kill -ABRT $sleep_pid; exit 1' 1 2 3 15
    sleep $DNS_TIMEOUT &
    sleep_pid=$!
    wait $sleep_pid
    kill -9 $command_pid
    exit 1
  ) &
  timeout_pid=$!  # pid of the timeout process

  # Wait for command, or timeout
  wait $command_pid
  status=$?

  # cleanup timer (if still running)
  kill $timeout_pid 2>/dev/null
  wait $timeout_pid 2>/dev/null
  exit $status
}
IP=`do_nslookup google.com`
echo "Google is at IP address: $IP"

=======8<--------

The last method has now been built into a program
   http://www.ict.griffith.edu.au/anthony/software/#timeout
Which includes linkes to a simple test progrom called "countdown"

It can be tested with
   timeout 5 countdown
   timeout 12 countdown


--- Attempt 4 ---

This runs the check program as a sub-shell monitoring the original process
ID, which exec'ed to the given command.  As such when the command exits the
main process exists immediatally.

However the 'sleep' will still what for a maximum 'interval' period before
the sub-process realises the command has finished, and it no longer needs
to monitor it.

But the pid of the command is preserved so parents can still kill its child
if they want to.

Program by Geoff Clare <gwc@root.co.uk>, 13 Feb 1998
Updated by Chet Ramsy (bash maintainer)

  timeout=60   # timeout
  interval=15  # intervial beteen 'still runing' checks
  SIG=-TERM    # signal to send
  delay=2      # delay from signal and doing a KILL
  (
    for t in $timeout $delay
    do
      while (( $t > $interval ))
      do
        sleep $interval
        kill -0 $$ || exit
        t=$(( $t - $interval ))
      done
      sleep $t
      kill $SIG $$ && kill -0 $$ || exit
      SIG=-KILL
    done
  ) 2> /dev/null &
  exec COMMAND TO RUN

-------------------------------------------------------------------------------
Protecting shell scripts from ^Z

This signal can't normally be stopped in a shell, the trick is to change
key generating the signal (Don't forget to return it to normal).

   stty susp undef      -- if available
   stty susp '^-'       -- maybe    system dependant

-------------------------------------------------------------------------------
Progress Reporting

file_progress
  Extract a processes read offset using "lsof"
    http://www.ict.griffith.edu.au/anthony/software/#file_progress

pv or "pipeview"
  When reading from a fixed file the 'pv' or "pipe viewer" command
  tells you how much progress has been made.

    pv somefile | gzip > rt94-171-06.gz
        128MB 0:00:15 [ 9.1MB/s] [=====>.....................] 18% ETA 0:01:07

  When taring up a directory getting disk size first is needed

    tar -czf - . | pv -s $(du -sb | grep -o '[0-9]*') > out.tgz
      44.3MB 0:00:27 [1.73MB/s] [>..........................] 0% ETA 13:36:22

  If size is not known, it just shows 'activity' indicator, and how
  much has been read, for how long, and average speed of data transfer

    pv /dev/urandom > /dev/null
    38.2MB 0:00:03 [12.8MB/s] [  <=>                      ]


A perl method with time: spent, left, and total;
This is better as it shows how long it has run and how long to go.
It shows how much that time is varying (from changes to predicted total time).
However this fails if there are major changes in progress rate.


Bar Graph...

percent
  Easy barchart display script
     http://www.ict.griffith.edu.au/anthony/software/#percent

This is a all bash method (except for the sleep)

  bar="=================================================="
  barlength=${#bar}
  i=0
  while ((i < 100)); do
    n=$((i*barlength / 100))       # Number of bar segments to draw $((i/2))
    printf "\r[%-${barlength}s]" "${bar:0:n}"
    ((i += RANDOM%5+2))            # i = percentage done
    sleep 1
  done
  echo

Of course 'i' should be set from somewhere meaningful.

The various "dialog" apps has a progress bar, but they either totally take
over the terminal window or are X window popups.

See also   http://mywiki.wooledge.org/BashFAQ/044

-------------------------------------------------------------------------------
Random number generation in a shell

  See "info/shell/random.txt

  nawk:
     set range  = ????
     set random = `nawk 'BEGIN { srand();
               printf "%d",  rand()*'$range'
              }' /dev/null`

  date: (not very good - except as a seed)
     set range  = ????     # file length -- `wc -l <$file`
     set date   = `date +%j%H%M%S`
     set random = `expr $date \% $range`

  shuf
      shuf -n 1 -i 1-99

      shuf -n 1 -e hearts diamonds clubs spades

      shuf -n 1 /usr/share/dict/words

  (k/z/ba)sh
      $RANDOM
    Posible improvment...
          !/bin/bash
          MX="0123456789"
          NL="5"   # size of the random number wanted
          while [ ${n:=1} -le $NL ]
          do
            NUM="$NUM${MX:$(($RANDOM%${#MX})):1}"
            let n+=1
          done
          echo "$NUM"

  Programed (csh) (could be via expr too)
     set multiplier = 25173
     set modulus =    65536
     set increment =  13849
     set seedfile =   $HOME/.rnd  # seed file to use

     if ( ! -f $seedfile ) then
       echo '17' > $seedfile
     endif

     @ number = ( `cat $seedfile` * $multiplier + $increment ) % $modulus
     echo $number > $seedfile

     @ number = $number % $range
     echo $number

-------------------------------------------------------------------------------
increment a character in shell

    char=`echo $char | tr ' -~' '\!-~'`

or (sutable for hex chars)

    str1="ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    str2="BCDEFGHIJKLMNOPQRSTUVWXYZA"
    pos=`expr index $str1 $char`
    char=`expr substr $str2 $pos 1`
    echo $char

In perl the "increment alpha string" makes this easy

   char=abzzz
   increment=`perl -e '$n="'"$char"'"; print ++$n'`
   echo $increment

   acaaa

-------------------------------------------------------------------------------
Argument Replacement Wrapper (BASH)

This function replaces the "convert" command options with 'newer' versions
of the same option.

  convert() {
    # go through arguments  and replace "-rotate" with "+distort" "SRT"
    args=()    # empty array
    for arg in "$@"; do
      case "$arg" in
      "-rotate") args=( "${args[@]}" "+distort" "SRT" ) ;;
      "-matte")  args=( "${args[@]}" "-alpha" "set" ) ;;
      "+matte")  args=( "${args[@]}" "-alpha" "off" ) ;;
      *) args=( "${args[@]}" "$arg" ) ;;   # just copy argument as is
      esac
    done

    # call the the REAL command (with debugging output)
    echo "DEBUG: convert ${args[*]}"
    command convert "${args[@]}"
  }
  convert rose: -matte -background none -rotate 40 show:

The above also allows you to add things like
  * set up environment (LD_LIBRARY_PATH, TMPDIR) for the command
  * path to the command to execute, or call a different command
  * prefix extra setup options or other hidden options
  * create 'fake' options that expand (macro-like) to more complex options
  * call other programs to pre-determine the options to use (for the version)

WARNING: Watch out that for arguments that look like options...
For example

  convert rose:  -gravity center -annotate 0 "-matte" show:

Here "-matte" is a string argument, and not a option!
Used as is with the above example function will results in

   convert rose:  -gravity center  -annotate 0 -alpha set show:

which will annotate the string "-alpha" instead of "-matte",
and generating the warning:  "unable to open image 'set'"

The only real fix is to give the wrapper a understanding of how many arguments
each and every option needs, which is getting a little ridiculous (see next).

---

The following is a more complex version that will take care options
that could take multiple arguments, and keep such arguments separate.
However this is really getting too difficult as you need to start looking
at very option that has arguments!

  convert() {
    # go through arguments  and replace "-rotate" with "+distort" "SRT"
    args=()        # the arguments for the real command
    option=()      # option and arguments (may have multiple arguments)
    count=0        # number of arguments to still add to option
    for arg in "$@"; do

      # collect arguments into multi-word options
      if [ $count -eq 0 ]; then
        option=()
        option="$arg"              # note that this is an option
        case "$option" in
          "-annotate") count=2 ;;  # annotate has two arguments
          "-rotate")   count=1 ;;  # rotate has one argument
        esac
      else
        # read in any more option arguments needed
        option=( "${option[@]}" "$arg" )
        count=$( expr $count - 1 )
      fi
      [ $count -gt 0 ] && continue

      # Substitute options with replacements
      case "$option" in
        "-matte")   option=( "-alpha" "set" ) ;;
        "+matte")   option=( "-alpha" "off" ) ;;
        "-rotate")  option=( "-virtual-pixel" "background"
                             "+distort" "SRT" "${option[1]}"
                           ) ;;
      esac
      args=( "${args[@]}" "${option[@]}" )  # just copy option as is

    done

    # call the command - printing what will actually be executed
    echo "DEBUG: magick ${args[*]}"
    command magick "${args[@]}"
  }

For example this will now work...

  convert rose: -gravity center -annotate 0 "-matte" \
          -matte -background none -rotate 40 show:

-------------------------------------------------------------------------------
Curses in shell script
To use termcap entries in a shell script use the `tput' command
EXAMPLES
    /usr/5bin/tput bold            # bold (extra half brigtht mode)
    /usr/5bin/tput bink            # bink mode (if available)
    /usr/5bin/tput rev             # reverse video
    /usr/5bin/tput smul            # underline mode
    /usr/5bin/tput smso            # standout (usually reverse)
    /usr/5bin/tput rmso            # end standout  (return to normal)
    /usr/5bin/tput clear           # clear screen
    /usr/5bin/tput cup 5 23        # cursor to move to row 5 column 23
See terminfo(5) for more info.

-------------------------------------------------------------------------------
Find processes of a particular name

Using grep (but ignore all grep processes)

  ps auxgww | grep "$NAME" | grep -v grep | cut -c1-15,36-99

Merging the two greps..

  ps uxw | grep "[s]sh-agent" | awk '{print $2}'

The regular expression "[s]sh-agent" will not match the grep process itself!
EG: It will not match the "[s]sh-agent" string in the grep process

Using awk (but ignoring all awk processes)...

  ps auxgww | awk "/$NAME/ && \! /(awk)/" | cut -c1-15,36-99

or for a exact process name

  ps auxgww | awk '/(^| |\(|\/)$NAME( |\)|$)/' | cut -c1-15,36-99

or alturnativeally which matches under a lot of conditions...
EG: matches    :01 NAME arg
               :01 some/path/NAME
               :01 NAME:

  ps auxgww | \
    awk '/:[0-9][0-9] (|[^ ]*\/)$NAME($| |:)/' | cut -c1-15,36-99

Perl version (also matches on username)

   ps auxgww | \
     perl -nle 'print if $. == 1   \
                      || /^\s*\!:1\s/o  \
                      || /:\d\d (|\[ *|[^ ]*\/)\!:1($|[]: ])/o; '

As you can see things can get complex very quickly

-------------------------------------------------------------------------------
Context Grep
Or how to display lines before/after search pattern.

GNU grep, has context built in to it, check out the -A, -B, and -C options.

No gnu-grep

   grep -v pattern file | diff -c3 - file | grep '^. ' | colrm 1 2

or

   grep -n $1 $2 | awk -F: '{ print $1 }' | while read linenum
   do
        awk 'NR>target-5 && NR<target+5 { print }' target=$linenum $2
        echo "-------next match---------"
   done

See also the perl script "cgrep"

-------------------------------------------------------------------------------
Humanize Data Size

See also "perl/general.txt"  for simular humanization techniques...
Not just for size but also time ranges

humanize() {
  # Given a number in Kb, humanize it
  # No space between number and ISO units means "sort -h" can sort it
  case "$1" in
    *???????????) echo "$(( swap / 1024 / 1024 /1024 ))Tb" ;;
    *????????)    echo "$(( swap / 1024 / 1024 ))Gb" ;;
    *?????)       echo "$(( swap / 1024 ))Mb" ;;
    *)            echo "${swap}Kb" ;;
  esac
}

humanize() {
  awk 'BEGIN { size='"$1"';
    if ( size < 800 ) { printf("%.1f Kbytes", size); exit; } size /= 1024;
    if ( size < 800 ) { printf("%.1f Mbytes", size); exit; } size /= 1024;
    if ( size < 800 ) { printf("%.1f Gbytes", size); exit; } size /= 1024;
    if ( size < 800 ) { printf("%.1f Tbytes", size); exit; } size /= 1024;
    printf("%.1f Pbytes", size);
  }'
}

-------------------------------------------------------------------------------
Parellelized Workers

Also See  "info/apps/find.txt"
for recursive compression of files that are not already compressed


Download Multiple files from web...

  cat url_list |
    parallel "wget -q {} 2>/dev/null || echo {} >> url_failed "
  #or
  cat url_list |
    xargs -r -i -n1 -P8 "wget -q {} 2>/dev/null || echo {} >> url_failed "


Process in batches of N (bzip2)

  # Run N jobs, and wait for all of them, before starting next 8
  while :; do
    parallel=8
    files_todo=( `ls * | grep -v '.bz2$' | head -$parallel` )
    [ "x$files_todo" = "x" ] && break

    for file in "${files_todo[@]}"; do
      bzip2 -9 "$base" &
    done
    wait
  done


Using Bash job control

  #!/bin/bash
  #
  # Check how many jobs are running, and add more if not enough.
  # Runstuff is the worker job (whereever that may be)
  #
  # WARNING: all jobs remain 'zombied' until all jobs finished!
  # This needs some major improvement.
  #

  runstuff() {
    : do the task given with arguments provided
  }

  maxjobs=8
  parallelize () {
    while [ $# -gt 0 ]; do
      count=(`jobs -p`)   # any free job slots?
      if [ ${#count[@]} -lt $maxjobs ]; then
        runstuff $1 &
        shift
      else
        sleep .0001   # wait a bit before trying again
      fi
    done
    wait   # wait for last jobs to finish
  }

  parallelize argv1 "argv2-1 argv2-2b" argv3 ... argvn


-------------------------------------------------------------------------------
Shell functions can have '/' or :: in there names!

   $ function /bin/echo () { builtin echo whoops; }
   $ /bin/echo pardon
   whoops
   $ unset -f /bin/echo

   $ function foo::bar () { builtin echo yes; }
   $ foo::bar no
   yes
   $ unset -f foo::bar

That means you CAN substitute a command that uses a full file path!

This does not work for imported functions - thanks to shell-shock

-------------------------------------------------------------------------------


