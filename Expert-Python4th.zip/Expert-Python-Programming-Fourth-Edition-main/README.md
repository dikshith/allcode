# Expert-Python-Programming-Fourth-Edition
Expert Python Programming, Fourth Edition published by Packt

For package versions used in examples see `requirements.txt` file.
