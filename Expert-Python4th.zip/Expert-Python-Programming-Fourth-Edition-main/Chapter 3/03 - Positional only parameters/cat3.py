def cat(*items, delim: str):
    return delim.join(items)
