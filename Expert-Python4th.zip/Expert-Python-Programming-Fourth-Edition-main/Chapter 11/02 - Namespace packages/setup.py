from setuptools import setup


setup(
    name="acme.templating",
    packages=["acme.templating"],
)
