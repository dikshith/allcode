function tputTests()
{

printf "====================================================================================\n"
printf "TPUT TESTS START\n"
printf "====================================================================================\n"

echo "Throughput test for 8K BS" >> result.txt
echo "dd if=/dev/zero of=/u01/test/file1.dat count=256 bs=1M" >> result.txt
echo 3 > /proc/sys/vm/drop_caches
time dd bs=1M count=256 if=/dev/zero of=/u01/test/file1.dat oflag=dsync 2>> result.txt 1> /dev/null &

printf "====================================================================================\n"
printf "TPUT TESTS COMPLETE\n"
printf "====================================================================================\n"
}
> result.txt
date
logfile=`date|tr " " "_"|tr ":" "_"`
iostat -xtcm 5 >> iostat_$logfile.log &
iopid=`pgrep iostat`
echo "iostat pid is $iopid"

sar -u 10 -o sar_"$logfile"_DomU_CPU.txt > /dev/null 2>&1 &
sar -r 10 -o sar_"$logfile"_DomU_MEM.txt > /dev/null 2>&1 &
sar -u -n DEV 10 -o sar_"$logfile"_DomU_NET.txt > /dev/null 2>&1 &

tputTests

pkill -u root iostat
pkill -u root sar
date
cp result.txt result_$logfile.txt
