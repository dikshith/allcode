#/bin/bash
# This script takes 2 argument as input(zone and hostname)
# example ./instancedetails.sh 11 DBaaS-PSR-10Oct

for (( z=$1; z <=$1; z++ ))
do
zone=z$z
API=$(eval echo \$$zone)

rm /tmp/instancedetails.txt;

nimbula-api list instance /   -Fname | grep -i $2 >> /tmp/1.txt

nimbula-admin list node /  -Fendpoint,instances | grep -i $2 | awk '{print $1}' >> /tmp/2.txt

nimbula-api list storagevolume /  -Fname | grep -i $2 >> /tmp/3.txt


File1="/tmp/3.txt";
while read -r line
do
        nimbula-api list storagevolume $line -fjson | grep "storage_pool" | awk '{print $2}' >> /tmp/4.txt

done < "$File1"

echo "instance" >> /tmp/instancedetails.txt
cat /tmp/1.txt >> /tmp/instancedetails.txt
#echo "\n" >> /tmp/instancedetails.txt

echo " domo" >> /tmp/instancedetails.txt
cat /tmp/2.txt >> /tmp/instancedetails.txt
#echo "\n" >> /tmp/instancedetails.txt

echo " storage volume details" >> /tmp/instancedetails.txt
#echo "\n" >> /tmp/instancedetails.txt
cat /tmp/3.txt >> /tmp/instancedetails.txt
#echo "\n" >> /tmp/instancedetails.txt

echo " Filere details " >> /tmp/instancedetails.txt
#echo "\n" >> /tmp/instancedetails.txt
cat /tmp/4.txt >> /tmp/instancedetails.txt

echo " " >> /tmp/instancedetails.txt

echo "Lun details" >> /tmp/instancedetails.txt

#rm /tmp/1.txt /tmp/2.txt /tmp/3.txt /tmp/4.txt


File1="/tmp/2.txt";
while read -r line
do
       domip=$line
done < "$File1"
#nimbula-exec -n $domip -c "cat /var/run/bnode/storage_cache | python -m json.tool" >> /tmp/5.txt
nimbula-exec -u /admin/psubbuku -p paas -a $API --nodeuser=psubbuku --nodepass=paas -n $domip -c "cat /var/run/bnode/storage_cache | python -m json.tool" >> /tmp/5.txt

#nimbula-exec -u /admin/PSUBBUKU -p paas -a $API --nodeuser=PSUBBUKU --nodepass=paas -n $domip -c "cat /var/run/bnode/storage_cache | python -m json.tool" >> /tmp/5.txt
#nimbula-exec  --nodeuser=psubbuku --nodepass=paas -n $domip -c "cat /var/run/bnode/storage_cache | python -m json.tool" >> /tmp/5.txt

File1="/tmp/1.txt";
while read -r line
do
       instancename=$line
done < "$File1"

grep  -iA 20 "\"name\": \"$instancename" /tmp/5.txt | grep 'lun\|storage_volume_name' -A 1 | grep 'name\|storage_volume_name\|lun' | awk -F ":" '{print $3}' >> /tmp/instancedetails.txt

done

rm /tmp/1.txt /tmp/2.txt /tmp/3.txt /tmp/4.txt /tmp/5.txt
