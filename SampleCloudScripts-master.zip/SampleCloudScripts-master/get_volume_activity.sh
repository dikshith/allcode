#./get_volume_activity.sh 26 20160214 20160215 /backup/bhushan/psubbuku/sandip/lun_creation_logs
#./get_volume_activity.sh zone startdate enddate logDir
zone=z$1
API=$(eval echo \$$zone)
d11=`date +%Y-%m-%d_%H-%M-%S`
logDir=$4
if [ "${logDir}" = "" ]; then
logDir="logs"
fi

mainLogDir="${logDir}/$d11"
mkdir -p ${mainLogDir}

todaydate=`date "+%Y%m%d"`
fromdate=`echo $(($(($(date -d "$todaydate" "+%s") - $(date -d "$2" "+%s"))) / 86400))`
todate=`echo $(($(($(date -d "$todaydate" "+%s") - $(date -d "$3" "+%s"))) / 86400))`
echo $todaydate, $fromdate, $todate;
for (( z=$fromdate; z >=$todate; z-- ))
do
        d=`date -d "${z} day ago" "+%Y%m%d"`
        f="/var/log/messages-${d}"
        echo "$f*" >> $mainLogDir/list${zone}.txt
                d1=`date -d "${z} day ago" "+%Y-%m-%d"`
                echo "$d1" >> $mainLogDir/dates${zone}.txt
done
paste -d, -s $mainLogDir/list${zone}.txt >> $mainLogDir/filelist${zone}.txt;
sed 's/,/ /g' $mainLogDir/filelist${zone}.txt >  $mainLogDir/filelist1${zone}.txt
file1=$mainLogDir/filelist1${zone}.txt;
while read -r line
do
        filenames=$line;
        if [ "$2" == "$3" ]
        then
        echo "$filenames /var/log/messages";
        else
        echo "$filenames";
        fi

done <"$file1"

mkdir $mainLogDir/HourlyBreakup

file=$mainLogDir/dates${zone}.txt
while read -r line
do
        echo "${line}T00" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T01" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T02" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T03" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T04" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T05" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T06" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T07" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T08" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T09" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T10" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T11" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T12" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T13" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T14" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T15" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T16" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T17" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T18" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T19" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T20" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T21" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T22" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}T23" >> $mainLogDir/HourlyBreakup/${line}.txt
        echo "${line}.txt" >> $mainLogDir/HourlyBreakup/filelist.txt
done <"$file"

##Need  to run only on bstorageworker
sh dadoorch/getControlPlaneNodes.sh -u /admin/psubbuku -p $zone -A $API -d $mainLogDir
#oc-service list bstorageworker_iscsi_101 -u $USER -p $PASSWORD -a $NIMBULA_API --nodeuser $NODEUSER -n $NODEPASS |grep bstorageworker >$mainLogDir/bstorageworker_IP.txt
while read -r line;do
IP=`echo $line`

nimbula-exec -u /admin/psubbuku -p $zone -a $API --nodeuser=psubbuku --nodepass=$zone -n $IP -c "zgrep '\"add\",\ \"type\":\ \"storage.volume.add\",\ \"result\":\ 201\|has\ been\ selected\ to\ host\ new\ storage\ volume\|Successfully\ created\ the\ volume\|,\ .get\ lunguid.\]\ took\ ' $filenames " >>$mainLogDir/logs_${zone}.txt

done < "$mainLogDir/controlNodeIp.txt"



######parsing logic to get results###########
####Need to write other logics#####


function parsedata()
{

        input_raw=$1
        logDir=$2
        grep "Successfully created the volume" $input_raw > $logDir/volume_created_raw.txt
        while read -r line;
        do
                Time_stamp=`echo $line|awk -F "]" '{print $1}'|awk -F "[" '{print $2}'`
                Volume_name=`echo $line|awk '{print $19}'`
                contextid=`echo $line |awk -F "@context:" '{print $2}' | awk '{print $1}'`
                echo "$Time_stamp,$Volume_name,$contextid" >> $logDir/volume_created.txt
        done < "$logDir/volume_created_raw.txt"

        grep '"action": "add", "type": "storage.volume.add", "result": 201' $input_raw > $logDir/volume_creation_request_raw.txt
        while read -r line
        do
                echo $line | awk -F "@context:" '{print $2}'| awk '{print $1}' >> tm.txt
                echo $line | awk -F "name\": \"" '{print $2}' | awk -F "\"" '{print $1}' >> tm.txt
                echo $line | awk -F "size\": \"" '{print $2}' | awk -F "\"" '{print $1}' >> tm.txt
                echo $line | awk -F "\"for_user\": \"" '{print $2}' | awk -F "\"" '{print $1}' >> tm.txt
                echo $line | awk -F "\"date\": \"" '{print $2}' | awk -F "\"" '{print $1}' >> tm.txt
                paste -d, -s tm.txt >>$logDir/volume_creation_request.txt
                rm tm.txt
        done < "$logDir/volume_creation_request_raw.txt"

        grep "has been selected to host new storage volume" $input_raw > $logDir/storagepooldetails_raw.txt
        while read -r line
        do
                echo $line | awk -F "@context:" '{print $2}'| awk '{print $1}' >> tm.txt
                echo $line | awk -F "Pool \"" '{print $2}' | awk -F "\"" '{print $1}' >> tm.txt
                echo $line | awk -F "volume \"" '{print $2}'| awk -F "\"" '{print $1}' >> tm.txt
                paste -d, -s tm.txt >> $logDir/storagepooldetails.txt
                rm tm.txt
        done < "$logDir/storagepooldetails_raw.txt"

        grep ',\ .get\ lunguid.\]\ took\ ' $input_raw | grep "[nimbula.bstorageworker]" > $logDir/ZFS_RT_raw.txt
        while read -r line
        do
                echo $line | awk -F "@context:" '{print $2}'| awk '{print $1}' >> tm.txt
                echo $line | awk -F "]" '{print $1}'|awk -F "[" '{print $2}' >> tm.txt
                echo $line | awk -F "took " '{print $2}'| awk -F " for executing on ZFS" '{print $1}'| sed 's/(//' | sed 's/)//' >> tm.txt
                paste -d, -s tm.txt >> $logDir/ZFS_RT.txt
                rm tm.txt
        done < "$logDir/ZFS_RT_raw.txt"


}

parsedata $mainLogDir/logs_${zone}.txt $mainLogDir

while read -r line
do
        a=`grep $line $mainLogDir/volume_creation_request.txt | wc -l`
        echo "$line,$a">> $mainLogDir/totalrequestcountperday.txt
done < "$mainLogDir/dates${zone}.txt"
while read -r l
do
        while read -r line
        do
                a=`grep $line $mainLogDir/volume_creation_request.txt | wc -l`
                echo "$line,$a" >> $mainLogDir/HourlyBreakup/${l}_HourlyBreakup.txt
        done < "$mainLogDir/HourlyBreakup/$l"
done < "$mainLogDir/HourlyBreakup/filelist.txt"

x=$5
y="null"
if [ $x != $y ]
then
        while read -r line
        do
                a=`grep $line $mainLogDir/volume_creation_request.txt | grep $x|  wc -l`
                echo "$line,$a">> $mainLogDir/totalrequestcountperdayfor_${x}.txt
        done < "$mainLogDir/dates${zone}.txt"


        while read -r l
        do
                while read -r line
                do
                        a=`grep $line $mainLogDir/volume_creation_request.txt | grep $x | wc -l`
                        echo "$line,$a" >> $mainLogDir/HourlyBreakup/${l}_HourlyBreakup_for_${x}.txt
                        done < "$mainLogDir/HourlyBreakup/$l"
        done < "$mainLogDir/HourlyBreakup/filelist.txt"
fi

awk -F "," '{print $2}' $mainLogDir/volume_creation_request.txt> $mainLogDir/vol_list1.txt
#awk -F "," '{print $2}' $mainLogDir/volume_created.txt > $mainLogDir/vol_list2.txt


#echo "contextid@request,storagevolumename,size,user,starttime,endtime,volumename,contextid@response,contextidvolume,storagepool,volume,contextidzfs,zfstimestamp,ZFSRT" > $mainLogDir/finalresults1_withpropercontextid.txt

echo "contextid@request,storagevolumename,size,user,starttime,endtime,volumename,contextid@response,contextidvolume,storagepool,volume" > $mainLogDir/finalresults.txt

echo "volumename" >> $mainLogDir/listoffailedvolumes.txt;
d="main@"
while read -r line
do
        z=`grep -c $line $mainLogDir/volume_created.txt`
        if [ $z -gt 0 ]
        then
                a=`grep $line $mainLogDir/volume_creation_request.txt`
                #w=`grep $line $mainLogDir/volume_creation_request.txt | awk -F "," '{print $1}'`
                b=`grep $line $mainLogDir/volume_created.txt`
                c=`grep $line $mainLogDir/storagepooldetails.txt`
                #d=`grep $w $mainLogDir/ZFS_RT.txt`
                echo "$a,$b,$c" >> $mainLogDir/finalresults.txt

        else
                echo "$line" >> $mainLogDir/listoffailedvolumes.txt
        fi

done < "$mainLogDir/vol_list1.txt"
rm  $mainLogDir/vol_list1.txt
#rm $mainLogDir/vol_list2.txt

#rm $mainLogDir/vol_list.txt;
mkdir $mainLogDir/rawlogs
#rm $mainLogDir/list${zone}.txt
rm $mainLogDir/dates${zone}.txt
rm $mainLogDir/filelist${zone}.txt
rm $mainLogDir/filelist1${zone}.txt
rm $mainLogDir/clusters.txt
rm $mainLogDir/controlNodeIp.txt
rm $mainLogDir/controlCluster.txt
mv $mainLogDir/logs_${zone}.txt $mainLogDir/rawlogs
mv $mainLogDir/volume_created_raw.txt $mainLogDir/rawlogs
mv $mainLogDir/volume_creation_request_raw.txt $mainLogDir/rawlogs
mv $mainLogDir/storagepooldetails_raw.txt $mainLogDir/rawlogs
mv $mainLogDir/ZFS_RT_raw.txt $mainLogDir/rawlogs
zip -r $mainLogDir/rawlogs.zip $mainLogDir/rawlogs

awk -F "," '{print $1,$2,$3,$10,$8,$5,$6}' $mainLogDir/finalresults.txt > $mainLogDir/FinalResults1.txt
#awk -F "," '{print $1,$2,$3,$10,$8,$5,$6}' $mainLogDir/finalresults1_withmain@contextid.txt > $mainLogDir/FinalResults_withmaincontextid.txt
grep -v "main@" $mainLogDir/FinalResults1.txt >> $mainLogDir/finalresults_withpropercontextid.txt
grep "main@" $mainLogDir/FinalResults1.txt >> $mainLogDir/finalresults_withmaincontextid.txt

rm $mainLogDir/FinalResults1.txt
rm $mainLogDir/finalresults.txt



#rm mainLogDir/finalresults1_withpropercontextid.txt $mainLogDir/finalresults_withmaincontextid.txt

