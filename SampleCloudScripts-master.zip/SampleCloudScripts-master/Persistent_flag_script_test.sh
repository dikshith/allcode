nimbula-api list orchestrationv2 / -f json > dataorchestrationv2.json
cat dataorchestrationv2.json | sed '/^         / d' | sed '/^        / d'| sed '/^       / d'| awk -F ':' '($1 ~ /"orchestration"/) || ($1 ~ /"persistent"/) || ($1 ~ /"type"/) || ($1 ~ /    "time_created"/)' | awk -F'":' '{print " "$2;}' | sed 's/\"//g' | sed 's/ //g' | awk 'ORS=NR%4?FS:RS' >> orchestrationv2_outputfile_$1.csv
sed -i 1i"Orchestration,Persistent,Time_Created,Type" orchestrationv2_outputfile_$1.csv
