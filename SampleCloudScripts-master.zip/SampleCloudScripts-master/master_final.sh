
wait()
{
  p=$1
  c=1
  while [ $c -gt 0 ];
  do
   #c=`ps -ef | grep $p | wc -l` 
   c=`ps -ef | grep $p | grep -v grep | wc -l`
    sleep 2
    echo -n "."
  done
}




#Test#1

fs=4 #file size gb
threads=6 #threads

for bs in 8
do
  
   bs=$(( $bs * 1024 ))  #block size bytes

   dateTag=$(date +%Y%m%d-%H%M%S)
   logDir=logs/$dateTag
   mkdir -p $logDir

   rm logs/latest
   ln -s $dateTag logs/latest

   echo "LogDir - $logDir"

   ./ddTest_writeonly.sh -t $threads -bs $bs -fs $fs -vol u01 -dt $dateTag > $logDir/test_1.log 2>&1 &
   pid=$!
   #./ddTest.sh -t $threads -bs $bs -fs $fs -vol nas45_400 -dt $dateTag > $logDir/test_2.log 2>&1 &

   echo "Test Started.. waiting for it to complete.."

   wait $pid

   echo "Test Completed!"

done
