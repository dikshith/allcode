USER=/admin/PSUBBUKU
Start_Zone=11
End_Zone=28
for (( z="$Start_Zone"; z <="$End_Zone"; z++ ))
do
zone=z$z
API=$(eval echo \$$zone)

nimbula-api list storagepool / -u $USER -a $API -p $zone -Fname,enabled,create_enabled,status|sed '1d' >>pan/$$

done

#parsing now 
echo "Filer, Zone, Storagepool, Enabled, Create Enabled, Status"
while read -r line;do
filer_name=`echo $line|awk -F "/" '{print $3}'|awk -F "-" '{print $1}'`
zone=`echo $line|awk -F "/" '{print $2}'`
pool=`echo $line|awk '{print $1}'`
enabled=`echo $line|awk '{print $2}'`
create_enabled=`echo $line|awk '{print $3}'`
status1=`echo $line|awk '{print $4}'`
echo "$filer_name, $zone, $pool, $enabled, $create_enabled, $status1"

done < "pan/$$"
rm pan/$$

