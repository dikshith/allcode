for (( z=28; z <=28; z++ ))
do
zone=z$z
API=$(eval echo \$$zone)
IP=`oc-service list nosql_admin -u /admin/PSUBBUKU -p $zone -a $API --nodeuser PSUBBUKU -n $zone|grep nosql_admin|head -n 1|cut -d " " -f 1`
nimbula-exec -u /admin/PSUBBUKU -p $zone -a $API --nodeuser=PSUBBUKU --nodepass=$zone -n $IP --put getvolume_json.py -d "/home/PSUBBUKU"
nimbula-exec -u /admin/PSUBBUKU -p $zone -a $API --nodeuser=PSUBBUKU --nodepass=$zone -n $IP -c "python getvolume_json.py > out.txt"
nimbula-exec -u /admin/PSUBBUKU -p $zone -a $API --nodeuser=PSUBBUKU --nodepass=$zone -n $IP --get "/home/PSUBBUKU/out.txt"
nimbula-exec -u /admin/PSUBBUKU -p $zone -a $API --nodeuser=PSUBBUKU --nodepass=$zone -n $IP -c "rm /home/PSUBBUKU/out.txt"
nimbula-exec -u /admin/PSUBBUKU -p $zone -a $API --nodeuser=PSUBBUKU --nodepass=$zone -n $IP -c "rm /home/PSUBBUKU/getvolume_json.py"
done
