#!/bin/bash
while [[ $# > 1 ]]
do
key="$1"
case $key in
    -e|--endpoint)
    ENDPOINT="$2"
    shift # past argument
    ;;
    -i|--identitydomain)
    TENANT="$2"
    shift # past argument
    ;;
    -u|--user)
    USER="$2"
    shift # past argument
    ;;
    -p|--pass)
    PASS="$2"
    shift # past argument
    ;;
    -size)
    SIZE_MB="$2"
    shift # past argument
    ;;
    -o|--outfile)
    OUTFILE="$2"
    shift # past argument
    ;;
    -c|--container)
    CONTAINER="$2"
    shift # past argument
    ;;
    -f|--file)
    LOCALFILE="$2"
    shift # past argument
    ;;
    -l|--leave)
    LEAVE=1
    ;;
    -h|--help)
    HELP=1
    ;;
    --default)
    DEFAULT=YES
    ;;
    *)
            # unknown option
    ;;
esac
shift # past argument or value
done
# Defaults
if [ -z "$SIZE_MB" ]; then
    SIZE_MB="1"
fi
if [ -z "$OUTFILE" ]; then
    OUTFILE="speed-test-output.json"
fi
if [ -z "$CONTAINER" ]; then
    # Random containder name
    CONTAINER="speed-test-container-`/usr/bin/uuidgen`"
fi
if [ -z "$ENDPOINT" ]; then
    echo "Must have endpoint via '-e' option"
    HELP=1
fi
if [ -z "$TENANT" ]; then
    echo "Must have tenant via '-t' option"
    HELP=1
fi
if [ -z "$USER" ]; then
    echo "Must have user via '-u' option"
    HELP=1
fi
if [ -z "$PASS" ]; then
    echo "Must have password via '-p' option"
    HELP=1
fi
if [ -n "$HELP" ]; then
    echo "Usage: speed-tests.sh -e {endpoint from cloud UI} -i {identity domain from cloud UI} -u {user name} -p {password} "
    echo "    optional: -size {size in mb: defaults to 1} "
    echo "    optional: -o {output json file name: defaults to speed-test-output.json} "
    echo "    optional: -c {container name: defaults to speed-test-container- + UUID} "
    echo "    optional: -f {container name: defaults to file- + UUID} in local directory "
    echo "    optional: -l leave the uploaded file"
    echo "    optional: -h which displays this help"
    echo ""
    echo "e.g. ./speed-test.sh -e https://storage.us2.oraclecloud.com/v1/tate1-tateidentitydomain -i tateidentitydomain -u 'tate.moore@oracle.com' -p 'myPassword' -size 10"
    echo ""
    echo "Will generate a test file of ¿-size¿ MB in the current directory then upload / download the file to your endpoiont."
    echo "The program will create by default an output file ¿speed-test-output.json¿ which has the following elements"
    echo "    date, operation, responseCode, url, timeConnectSec, timeTotalSec, bytes, bytesPerSecond"
    echo "e.g. "
    echo "    { \"date\" : \"2015-11-12T00:02:16Z\", \"operation\" : \"PUT\", \"responseCode\" : \"201\", \"url\" : \"https://storage.us2.oraclecloud.com/v1/tate1-tateidentitydomain/speed-test-container-005C4231-226F-4426-8624-A3C2917183A8/file-2455FF7D-138A-49DA-9BD6-2CC0C27FBDD8.out\", \"timeConnectSec\" : \"0.071\", \"timeTotalSec\" : \"19.203\", \"bytes\" : \"10485760\", \"bytesPerSecond\" : \"546044.000\" }"
    echo ""
    echo ""
    exit 0
fi
if [ -z "$LOCALFILE" ]; then
    GENERATED=1
    LOCALFILE="file-`/usr/bin/uuidgen`.out"
    # Create test file locally
    echo "Generating local file: $LOCALFILE"
    /bin/dd if=/dev/zero of=$LOCALFILE count=$SIZE_MB bs=1048576 >& /dev/null
fi
# Show commands
#set -x
# Create container in the endpoint
/usr/bin/curl -s --max-time 30 --connect-timeout 10 --retry 3 -X PUT -H "X-ID-TENANT-NAME: $TENANT" -u "$USER:$PASS" -H "Accept: application/json" -H "Cache-Control: no-cache" -o /dev/null "$ENDPOINT/$CONTAINER"
# Upload and then download the object
/bin/echo "Starting Upload: $ENDPOINT/$CONTAINER/$LOCALFILE"
/usr/bin/curl --max-time 3600 --connect-timeout 10 --retry 3 -X PUT -w "{ \"date\" : \"`/bin/date -u +%Y-%m-%dT%H:%M:%SZ`\", \"operation\" : \"PUT\", \"responseCode\" : \"%{http_code}\", \"url\" : \"$ENDPOINT/$CONTAINER/$LOCALFILE\", \"timeConnectSec\" : \"%{time_connect}\", \"timeTotalSec\" : \"%{time_total}\", \"bytes\" : \"%{size_upload}\", \"bytesPerSecond\" : \"%{speed_upload}\" }\n" -H "X-ID-TENANT-NAME: $TENANT" -u "$USER:$PASS" -H "Accept: application/json" -H "Cache-Control: no-cache" -o /dev/null --upload-file $LOCALFILE "$ENDPOINT/$CONTAINER/$LOCALFILE" >> $OUTFILE
/bin/echo "Starting Download: $ENDPOINT/$CONTAINER/$LOCALFILE"
/usr/bin/curl --max-time 3600 --connect-timeout 10 --retry 3 -X GET -w "{ \"date\" : \"`/bin/date -u +%Y-%m-%dT%H:%M:%SZ`\", \"operation\" : \"GET\", \"responseCode\" : \"%{http_code}\", \"url\" : \"$ENDPOINT/$CONTAINER/$LOCALFILE\", \"timeConnectSec\" : \"%{time_connect}\", \"timeTotalSec\" : \"%{time_total}\", \"bytes\" : \"%{size_download}\", \"bytesPerSecond\" : \"%{speed_download}\" }\n" -H "X-ID-TENANT-NAME: $TENANT" -u "$USER:$PASS" -H "Accept: application/json" -H "Cache-Control: no-cache" -o /dev/null "$ENDPOINT/$CONTAINER/$LOCALFILE" >> $OUTFILE
if [ -n "$LEAVE" ]; then
    echo "Leaving file: $ENDPOINT/$CONTAINER/$LOCALFILE"
else
    # Clean up test container
    /usr/bin/curl -s --max-time 30 --connect-timeout 10 --retry 3 -X DELETE -H "X-ID-TENANT-NAME: $TENANT" -u "$USER:$PASS" -H "Accept: application/json" -H "Cache-Control: no-cache" -o /dev/null "$ENDPOINT/$CONTAINER/$LOCALFILE"
    /usr/bin/curl -s --max-time 30 --connect-timeout 10 --retry 3 -X DELETE -H "X-ID-TENANT-NAME: $TENANT" -u "$USER:$PASS" -H "Accept: application/json" -H "Cache-Control: no-cache" -o /dev/null "$ENDPOINT/$CONTAINER"
fi
if [ -n "$GENERATED" ]; then
    # Clean up test file locally
    /bin/rm $LOCALFILE
fi