#!/bin/bash

DATE=`date '+%m-%d-%y-%H-%M-%S'`
OUTDIR=`pwd`/output
mkdir -p $OUTDIR
OUTFILE_1=$OUTDIR/dd_direct.out
OUTFILE_2=$OUTDIR/dd_buffered.out

cnt=$2
int=$1
iostat -xkt 1 >& $OUTDIR/iostat_direct.out.$DATE.dat &
for ((i=1;i<=$cnt;i++));
do
date >>$OUTFILE_1
dd if=/dev/zero of=$OUTDIR/dd_testfile count=1000 bs=8192 oflag=direct >>$OUTFILE_1 2>&1
done

ps -ef|grep "iostat -xkt"|grep -v grep |awk  '{print $2}'|xargs kill

iostat -xkt 1 >& $OUTDIR/iostat_buffered.out.$DATE.dat &
for ((i=1;i<=$cnt;i++));
do
date >>$OUTFILE_2
dd if=$OUTDIR/dd_testfile of=$OUTDIR/dd_testfile.cp count=1000 bs=8192 >>$OUTFILE_2 2>&1
done

ps -ef|grep "iostat -xkt"|grep -v grep |awk  '{print $2}'|xargs kill

rm -f $OUTDIR/dd_testfile*