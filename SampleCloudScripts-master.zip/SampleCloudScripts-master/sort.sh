grep "nimbula_director" $1>     nimbula.log
awk -F  '[][]' '{print $4}' nimbula.log>dates.log
paste dates.log nimbula.log>temp.log
sort -k1 temp.log>${1}_final.log
rm temp.log
rm  dates.log
rm nimbula.log
echo ${1}_final.log
