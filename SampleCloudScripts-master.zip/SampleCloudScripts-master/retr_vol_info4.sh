#!/bin/bash
#
# Filename: retr_vol_info4.sh
#
#
#
# History:
#
#    Senthil R.   2017-09-21   Created
#    Senthil R.   2017-11-21   Shows volume-name (volname1)
#    Senthil R.   2017-12-06   Shows Nimbula volume-name info (volname2)
#

if [[ $# < 1 ]]
then
   vm_id=$(sudo xm list | grep -v Name | grep -v Domain | awk '{print $2}' | paste -sd " " -)
else
   vm_id=$1
fi

mkdir -p /tmp/volinfo
echo "----------------------------------------------------------------------------------------------------------------------------------------------------------------------"
echo "VM-id vm-disk               WWN                     Filer                             LUN                                        dm-id      dom0-disks     vm-vbd"
echo "----------------------------------------------------------------------------------------------------------------------------------------------------------------------"

for i in ${vm_id}
do
   vmname=$(sudo xm list $i | grep -v Name | awk '{print $1}')
   sudo xm list -l $i > /tmp/volinfo/.xm_list.info
   sudo cat /var/run/bnode/storage_cache | python -m json.tool > /tmp/volinfo/.storage_cache.info
   sudo multipath -ll > /tmp/volinfo/.multipath_ll.info
   sudo xenstore ls > /tmp/volinfo/.xenstore_ls.info

   grep -A 5 "vbd" /tmp/volinfo/.xm_list.info | xargs -n 7 -d '\n' | awk '{print $9 $11}' | sed 's/)/ /g; s/:disk//; s/phy:\/dev\/mapper\/3//' | while read LINE
   do
      for j in $(echo $LINE | awk '{print $2}')
      do
         if [ -z $(echo $j | tr -d "[a-z0-9A-Z]") ]
         then
            devname=$(echo $LINE | cut -d " " -f1)
            filer=$(grep -i -B 5 $j /tmp/volinfo/.storage_cache.info | egrep "initiator|name" | xargs -n2 -d'\n' | awk '{print $2 $4}' | tr '"' ' ' | awk -F'_' '{print $5,$11}' | awk '{print $1}')
            lunname=$(grep -i -B 5 $j /tmp/volinfo/.storage_cache.info | egrep "initiator|name" | xargs -n2 -d'\n' | awk '{print $2 $4}' | tr '"' ' ' | awk '{print $NF}')
            volname1=$(grep -i -B 8 $j /tmp/volinfo/.storage_cache.info | head -1 | awk '{print $2}' | sed 's/"//g;s/,//g')
            volname2=$(grep -i -A 12 $j /tmp/volinfo/.storage_cache.info | tail -1 | awk '{print $2}' | sed 's/"//g;s/,//g')
            dm=$(grep $j /tmp/volinfo/.multipath_ll.info | grep dm | awk '{print $2}')
            devs=$(grep -A 6 $j /tmp/volinfo/.multipath_ll.info | egrep " active| ready| running" | awk '{print $3}' | xargs -n 4)
            vbdname=$(cat /tmp/volinfo/.xenstore_ls.info | grep -A 6 "domain = \"${vmname}" | grep -A 3 vbd | grep -B 3 ${devname} | head -1 | awk -F\" '{print $2}' | xargs basename)
            #echo $i $LINE $filer $lunname $dm $devs $vbdname
            echo " $i    $LINE  $filer $lunname $dm $devs $vbdname"
            echo "              ${volname1}"
            echo "              ${volname2}"
         fi
      done
   done
done
echo "----------------------------------------------------------------------------------------------------------------------------------------------------------------------"


