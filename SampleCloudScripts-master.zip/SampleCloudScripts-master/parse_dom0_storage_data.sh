#!/bin/bash

#[100.64.31.94] out: "instance_name": "5fa3da21-c8b7-48e0-86f8-9de9cf4ef9e0",
#[100.64.31.94] out: "iops_limit": 0,
#[100.64.31.94] out: "lease_id": null,
#[100.64.31.94] out: "logical_timestamp": null,
#[100.64.31.94] out: "management_addresses": [
#[100.64.31.94] out: "100.64.31.196"
#[100.64.31.94] out: ],
#[100.64.31.94] out: "migration_destination": null,
#[100.64.31.94] out: "multipath": true,
#[100.64.31.94] out: "name": "/Compute-a424136/jason_hatchell@ezcorp.com/chwn-pss-db01/02f6ef12-8cb0-43f7-b289-01216e43880e/5fa3da21-c8b7-48e0-86f8-9de9cf4ef9e0/0e83eb0f-e9de-4913-bd72-bffa811248e7",
#[100.64.31.94] out: "node_uuid": "550ebed6-ce79-4e81-b13a-52e4d1ba1da0",
#[100.64.31.94] out: "protocol_attributes": {
#[100.64.31.94] out: "default_initiator_group": "__compute-us2-z47__ord13-opc-c8r712-zfs-1-v1__storagepool__iscsi_group_703cbf55e90783a10c72caa211e96b4b",
#[100.64.31.94] out: "default_port": "3260",
#[100.64.31.94] out: "lun": {
#[100.64.31.94] out: "name": "723d0b42df447983c07ad7b539360528c02f3f3589aaf2e43e8c25139278ca9f"
#[100.64.31.94] out: },
#[100.64.31.94] out: "lunguid": "600144F0F3465AB00000593EA5930AA5",
#[100.64.31.94] out: "password": "XXXXX",
#[100.64.31.94] out: "project": "compute-us2-z47_iscsi",
#[100.64.31.94] out: "target_iqn": "iqn.1986-03.com.sun:02:24b3aa5a-75ed-e2aa-f08b-a39f07c216be",
#[100.64.31.94] out: "type": "iscsi",
#[100.64.31.94] out: "username": "root",
#[100.64.31.94] out: "zfs_zpool": "pool01a"
#[100.64.31.94] out: },
#[100.64.31.94] out: "readonly": false,
#[100.64.31.94] out: "shared": false,
#[100.64.31.94] out: "state": "attached",
#[100.64.31.94] out: "status_timestamp": null,
#[100.64.31.94] out: "storage_volume_name": "/Compute-a424136/jason_hatchell@ezcorp.com/chwn-pss-db01-vol2",

((i=1))
grep -A29 "instance_name" us2_z47_dom0_storage_cache.txt | while read LINE
do
   #echo $LINE
   str=$(echo ${LINE} | grep "instance_name")
   if [ ! -z "$str" ]
   then
      dom0_ip=$(echo ${LINE} | awk '{print $1}' | sed 's/\[//g;s/\]//g')
      domu_id=$(echo ${LINE} | grep "instance_name" | awk '{print $NF}' | sed 's/"//g;s/,//g')
      #echo $dom0_ip
      #echo $domu_id
   fi
   str=$(echo ${LINE} | grep "name" | grep "Compute" | grep -v "storage")
   if [ ! -z "$str" ]
   then
      instance_name=$(echo ${LINE} | grep "name" | grep "Compute" | grep -v "storage" | awk '{print $NF}' | sed 's/"//g;s/,//g')
      #echo $instance_name
   fi
   str=$(echo ${LINE} | grep "default_initiator_group")
   if [ ! -z "$str" ]
   then
      filer=$(echo ${LINE} | grep "default_initiator_group" | awk '{print $NF}' | awk -F'_' '{print $5,$11}' | awk '{print $1}' | sed 's/"//g;s/,//g')
      #echo $filer
   fi
   str=$(echo ${LINE} | grep "name" | grep -v "Compute" | grep -v "storage" | grep -v "username" | grep -v "instance_name")
   if [ ! -z "$str" ]
   then
      lunname=$(echo ${LINE} | grep "name" | grep -v "Compute" | grep -v "storage" | grep -v "username" | grep -v "instance_name" | awk '{print $NF}' | sed 's/"//g;s/,//g')
      #echo $lunname
   fi
   str=$(echo ${LINE} | grep "lunguid")
   if [ ! -z "$str" ]
   then
      lunguid=$(echo ${LINE} | grep "lunguid" | awk '{print $NF}' | sed 's/"//g;s/,//g')
      #echo $lunguid
   fi
   str=$(echo ${LINE} | grep "storage_volume_name")
   if [ ! -z "$str" ]
   then
      storage_volume_name=$(echo ${LINE} | grep "storage_volume_name" | awk '{print $NF}' | sed 's/"//g;s/,//g')
      #echo $storage_volume_name
      echo $dom0_ip,$domu_id,$instance_name,$filer,$lunname,$lunguid,$storage_volume_name
   fi
done
