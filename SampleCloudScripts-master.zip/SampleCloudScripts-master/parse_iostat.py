
import os
import sys
from collections import OrderedDict

def read_file(filename):
        if not os.path.exists(filename):
                raise Exception("File does not exist")
        with open(filename, 'r') as f:
                data = f.readlines()
                if not data or data == "":
                        raise Exception("File empty")
                return data     

def parse_data(data, threshold, filter_dm):
        errors = OrderedDict()
        current_timestamp = None
        for line in data:
                output = line.strip()
                if not output or output == "":
                        continue
                if "UTC" in output:
                        current_timestamp = output
                        errors[current_timestamp] = list()
                        continue
                if not current_timestamp:
                        continue
                
                splits = output.split()
                if splits and len(splits) == 12:
                        if splits[0] == "Device:":
                                continue
                        if (not filter_dm) or (filter_dm in splits[0]) or (filter_dm == "all"):
                                if splits[9] and float(splits[9]) > float(threshold):
                                        if (filter_timestamp == "all") or (filter_timestamp in current_timestamp):
                                                errors[current_timestamp].append(output)

        for timestamp in errors:
            for line in errors[timestamp]:
                print "%s %s" % (timestamp.split('***')[1], line)
        

filename = sys.argv[1]
threshold = sys.argv[2]
filter_dm = sys.argv[3]
filter_timestamp = sys.argv[4]
data = read_file(filename)
parse_data(data, threshold, filter_dm)
