#!/bin/bash

exe() { echo "\$ ${@/eval/}" ; "$@" ; }

exe uname -a
exe lsmod | grep -i xen
exe dmesg | grep -i xen
exe lsblk
exe echo /sys/bus/xen/devices/vbd*
exe dmesg | grep xen_netfront
exe ethtool -i eth0
exe echo /sys/bus/xen/devices/vif*
exe dmesg | grep 'Xen timer'
exe sudo dmidecode
exe grep XEN_PV /boot/config-*
exe cat /sys/hypervisor/properties/features

OUTPUT

****************************************************************************
ubuntu@None:~$ sudo  ./gather_xen_info.sh
$ uname -a
Linux None 4.4.0-116-generic #140-Ubuntu SMP Mon Feb 12 21:23:04 UTC 2018 x86_64 x86_64 x86_64 GNU/Linux
xen_fbfront            20480  1
syscopyarea            16384  1 xen_fbfront
sysfillrect            16384  1 xen_fbfront
sysimgblt              16384  1 xen_fbfront
fb_sys_fops            16384  1 xen_fbfront
[    0.000000] Command line: BOOT_IMAGE=/boot/vmlinuz-4.4.0-116-generic root=UUID=0e81df04-5844-485b-9c04-57ff59c98e79 ro console=tty1 console=ttyS0 xen-blkfront.max_ring_page_order=4 xen-blkfront.max=8
[    0.000000] DMI: Xen HVM domU, BIOS 4.4.4OVM 06/17/2017
[    0.000000] Hypervisor detected: Xen
[    0.000000] Xen version 4.4.
[    0.000000] Xen Platform PCI: I/O protocol version 1
[    0.000000] Netfront and the Xen platform PCI driver have been compiled for this kernel: unplug emulated NICs.
[    0.000000] Blkfront and the Xen platform PCI driver have been compiled for this kernel: unplug emulated disks.
[    0.000000] ACPI: RSDP 0x00000000000EA020 000024 (v02 Xen   )
[    0.000000] ACPI: XSDT 0x00000000FC00F740 000054 (v01 Xen    HVM      00000000 HVML 00000000)
[    0.000000] ACPI: FACP 0x00000000FC00F400 0000F4 (v04 Xen    HVM      00000000 HVML 00000000)
[    0.000000] ACPI: DSDT 0x00000000FC0035E0 00BD91 (v02 Xen    HVM      00000000 INTL 20090123)
[    0.000000] ACPI: APIC 0x00000000FC00F500 0000D8 (v02 Xen    HVM      00000000 HVML 00000000)
[    0.000000] ACPI: HPET 0x00000000FC00F650 000038 (v01 Xen    HVM      00000000 HVML 00000000)
[    0.000000] ACPI: WAET 0x00000000FC00F690 000028 (v01 Xen    HVM      00000000 HVML 00000000)
[    0.000000] ACPI: SSDT 0x00000000FC00F6C0 000031 (v02 Xen    HVM      00000000 INTL 20090123)
[    0.000000] ACPI: SSDT 0x00000000FC00F700 000031 (v02 Xen    HVM      00000000 INTL 20090123)
[    0.000000] Booting paravirtualized kernel on Xen HVM
[    0.000000] xen: PV spinlocks enabled
[    0.000000] Kernel command line: BOOT_IMAGE=/boot/vmlinuz-4.4.0-116-generic root=UUID=0e81df04-5844-485b-9c04-57ff59c98e79 ro console=tty1 console=ttyS0 xen-blkfront.max_ring_page_order=4 xen-blkfront.max=8
[    0.000000] xen:events: Using FIFO-based ABI
[    0.000000] xen:events: Xen HVM callback vector for event delivery is enabled
[    0.294385] clocksource: xen: mask: 0xffffffffffffffff max_cycles: 0x1cd42e4dffb, max_idle_ns: 881590591483 ns
[    0.296012] Xen: using vcpuop timer interface
[    0.296018] installing Xen timer for CPU 0
[    0.324085] installing Xen timer for CPU 1
[    0.340092] installing Xen timer for CPU 2
[    0.351011] installing Xen timer for CPU 3
[    0.487335] xen: --> pirq=16 -> irq=9 (gsi=9)
[    0.760089] xen:balloon: Initialising balloon driver
[    0.764038] xen_balloon: Initialising balloon driver
[    0.824050] clocksource: Switched to clocksource xen
[    0.860128] xen: --> pirq=17 -> irq=8 (gsi=8)
[    0.860171] xen: --> pirq=18 -> irq=12 (gsi=12)
[    0.860204] xen: --> pirq=19 -> irq=1 (gsi=1)
[    0.860239] xen: --> pirq=20 -> irq=6 (gsi=6)
[    0.860281] xen: --> pirq=21 -> irq=4 (gsi=4)
[    0.860325] xen: --> pirq=22 -> irq=7 (gsi=7)
[    1.380652] xen: --> pirq=23 -> irq=28 (gsi=28)
[    1.380737] xen:grant_table: Grant tables using version 1 layout
[    1.530974] xen_netfront: Initialising Xen virtual ethernet driver
[    1.788726] xenbus_probe_frontend: Device with no driver: device/vfb/0
[    5.003358] systemd[1]: Detected virtualization xen.
[   11.880036] xenbus_probe_frontend: Waiting for devices to initialise: 25s...20s...15s...10s...5s...0s...
[   36.880244] xenbus_probe_frontend: Timeout connecting to device: device/vfb/0 (local state 3, remote state 1)
$ lsblk
NAME    MAJ:MIN RM SIZE RO TYPE MOUNTPOINT
xvdb    202:16   0  10G  0 disk
└─xvdb1 202:17   0  10G  0 part /
xvdc    202:32   0  16G  0 disk
xvdd    202:48   0  16G  0 disk
$ echo /sys/bus/xen/devices/vbd-51728 /sys/bus/xen/devices/vbd-51744 /sys/bus/xen/devices/vbd-51760
/sys/bus/xen/devices/vbd-51728 /sys/bus/xen/devices/vbd-51744 /sys/bus/xen/devices/vbd-51760
[    1.530974] xen_netfront: Initialising Xen virtual ethernet driver
$ ethtool -i eth0
driver: vif
version:
firmware-version:
expansion-rom-version:
bus-info: vif-0
supports-statistics: yes
supports-test: no
supports-eeprom-access: no
supports-register-dump: no
supports-priv-flags: no
$ echo /sys/bus/xen/devices/vif-0
/sys/bus/xen/devices/vif-0
[    0.296018] installing Xen timer for CPU 0
[    0.324085] installing Xen timer for CPU 1
[    0.340092] installing Xen timer for CPU 2
[    0.351011] installing Xen timer for CPU 3
$ sudo dmidecode
# dmidecode 3.0
Getting SMBIOS data from sysfs.
SMBIOS 2.4 present.
17 structures occupying 490 bytes.
Table at 0x000EB01F.

Handle 0x0000, DMI type 0, 24 bytes
BIOS Information
        Vendor: Xen
        Version: 4.4.4OVM
        Release Date: 06/17/2017
        Address: 0xE8000
        Runtime Size: 96 kB
        ROM Size: 64 kB
        Characteristics:
                PCI is supported
                EDD is supported
                Targeted content distribution is supported
        BIOS Revision: 4.4

Handle 0x0100, DMI type 1, 27 bytes
System Information
        Manufacturer: Xen
        Product Name: HVM domU
        Version: 4.4.4OVM
        Serial Number: 595fe663-d7e8-44d6-ac33-185571986fdd
        UUID: 595FE663-D7E8-44D6-AC33-185571986FDD
        Wake-up Type: Power Switch
        SKU Number: Not Specified
        Family: Not Specified

Handle 0x0300, DMI type 3, 13 bytes
Chassis Information
        Manufacturer: Xen
        Type: Other
        Lock: Not Present
        Version: Not Specified
        Serial Number: Not Specified
        Asset Tag: Not Specified
        Boot-up State: Safe
        Power Supply State: Safe
        Thermal State: Safe
        Security Status: Unknown

Handle 0x0401, DMI type 4, 26 bytes
Processor Information
        Socket Designation: CPU 1
        Type: Central Processor
        Family: Other
        Manufacturer: Intel
        ID: F1 06 04 00 FF FB 89 17
        Version: Not Specified
        Voltage: Unknown
        External Clock: Unknown
        Max Speed: 2195 MHz
        Current Speed: 2195 MHz
        Status: Populated, Enabled
        Upgrade: Other

Handle 0x0402, DMI type 4, 26 bytes
Processor Information
        Socket Designation: CPU 2
        Type: Central Processor
        Family: Other
        Manufacturer: Intel
        ID: F1 06 04 00 FF FB 89 17
        Version: Not Specified
        Voltage: Unknown
        External Clock: Unknown
        Max Speed: 2195 MHz
        Current Speed: 2195 MHz
        Status: Populated, Enabled
        Upgrade: Other

Handle 0x0403, DMI type 4, 26 bytes
Processor Information
        Socket Designation: CPU 3
        Type: Central Processor
        Family: Other
        Manufacturer: Intel
        ID: F1 06 04 00 FF FB 89 17
        Version: Not Specified
        Voltage: Unknown
        External Clock: Unknown
        Max Speed: 2195 MHz
        Current Speed: 2195 MHz
        Status: Populated, Enabled
        Upgrade: Other

Handle 0x0404, DMI type 4, 26 bytes
Processor Information
        Socket Designation: CPU 4
        Type: Central Processor
        Family: Other
        Manufacturer: Intel
        ID: F1 06 04 00 FF FB 89 17
        Version: Not Specified
        Voltage: Unknown
        External Clock: Unknown
        Max Speed: 2195 MHz
        Current Speed: 2195 MHz
        Status: Populated, Enabled
        Upgrade: Other

Handle 0x0B00, DMI type 11, 5 bytes
OEM Strings
        String 1: Xen

Handle 0x1000, DMI type 16, 15 bytes
Physical Memory Array
        Location: Other
        Use: System Memory
        Error Correction Type: Multi-bit ECC
        Maximum Capacity: 30 GB
        Error Information Handle: Not Provided
        Number Of Devices: 2

Handle 0x1100, DMI type 17, 21 bytes
Memory Device
        Array Handle: 0x1000
        Error Information Handle: 0x0000
        Total Width: 64 bits
        Data Width: 64 bits
        Size: 16384 MB
        Form Factor: DIMM
        Set: None
        Locator: DIMM 0
        Bank Locator: Not Specified
        Type: RAM
        Type Detail: None

Handle 0x1300, DMI type 19, 15 bytes
Memory Array Mapped Address
        Starting Address: 0x00000000000
        Ending Address: 0x003FFFFFFFF
        Range Size: 16 GB
        Physical Array Handle: 0x1000
        Partition Width: 1

Handle 0x1400, DMI type 20, 19 bytes
Memory Device Mapped Address
        Starting Address: 0x00000000000
        Ending Address: 0x003FFFFFFFF
        Range Size: 16 GB
        Physical Device Handle: 0x1100
        Memory Array Mapped Address Handle: 0x1300
        Partition Row Position: 1

Handle 0x1101, DMI type 17, 21 bytes
Memory Device
        Array Handle: 0x1000
        Error Information Handle: 0x0000
        Total Width: 64 bits
        Data Width: 64 bits
        Size: 14336 MB
        Form Factor: DIMM
        Set: None
        Locator: DIMM 1
        Bank Locator: Not Specified
        Type: RAM
        Type Detail: None

Handle 0x1301, DMI type 19, 15 bytes
Memory Array Mapped Address
        Starting Address: 0x00400000000
        Ending Address: 0x0077FFFFFFF
        Range Size: 14 GB
        Physical Array Handle: 0x1000
        Partition Width: 1

Handle 0x1401, DMI type 20, 19 bytes
Memory Device Mapped Address
        Starting Address: 0x00400000000
        Ending Address: 0x0077FFFFFFF
        Range Size: 14 GB
        Physical Device Handle: 0x1101
        Memory Array Mapped Address Handle: 0x1301
        Partition Row Position: 1

Handle 0x2000, DMI type 32, 11 bytes
System Boot Information
        Status: No errors detected

Handle 0x7F00, DMI type 127, 4 bytes
End Of Table

$ grep XEN_PV /boot/config-4.4.0-112-generic /boot/config-4.4.0-116-generic
/boot/config-4.4.0-112-generic:CONFIG_XEN_PVHVM=y
/boot/config-4.4.0-112-generic:CONFIG_XEN_PVH=y
/boot/config-4.4.0-116-generic:CONFIG_XEN_PVHVM=y
/boot/config-4.4.0-116-generic:CONFIG_XEN_PVH=y
$ cat /sys/hypervisor/properties/features
00000705
ubuntu@None:~$ vi gather_xen_info.sh
ubuntu@None:~$
