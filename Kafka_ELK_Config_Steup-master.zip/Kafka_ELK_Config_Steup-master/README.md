create_keypair.py - Create Key Pair for EC2 Instance

create_instance.py - Create a New EC2 Instance

app01.py - connect to Kafka Topic and write some log

app02.py - write some log to log file to output file (ex: /var/log/application-output.log)

ansible-deployment - deploy for different roles:
									- ElasticSearch + Logstash + Kibana (ELK) 
									- extra: Apache Kafka + Filebeat